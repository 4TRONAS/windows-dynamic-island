@echo off
title Island check
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Island-check.ps1"
echo.
pause
