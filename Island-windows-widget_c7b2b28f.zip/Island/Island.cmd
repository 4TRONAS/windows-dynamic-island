@echo off
setlocal
cd /d "%~dp0"
rem ---------------------------------------------------------------
rem  ISLAND launcher
rem    Island.cmd                     open the island
rem    Island.cmd "your message"      push a notification into it
rem    Island.cmd --anchor-x 16 --anchor-y 552   start docked at a spot
rem ---------------------------------------------------------------
set "SELF=%~dp0Island.ps1"
set "PWP=powershell.exe -NoProfile -ExecutionPolicy Bypass"

if not exist "%SELF%" (
    echo  [Island] Island.ps1 is missing next to this .cmd
    echo           - extract the WHOLE Island folder from the zip first,
    echo             then double-click Island.cmd inside the folder.
    pause
    exit /b 1
)

if "%~1"=="" goto ui
if /i "%~1"=="--min" goto ui
if /i "%~1"=="kill" ( %PWP% -File "%SELF%" -Kill & exit /b )
if /i "%~1"=="debug" ( powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%SELF%" debug & pause & exit /b )
if /i "%~1"=="--anchor-x" (
    start "" %PWP% -WindowStyle Hidden -File "%SELF%" -Minimized -AnchorX %~2 -AnchorY %~4
    exit /b
)
%PWP% -File "%SELF%" -Notify %*
goto :eof

:ui
start "" %PWP% -WindowStyle Hidden -File "%SELF%" -Minimized
exit /b
