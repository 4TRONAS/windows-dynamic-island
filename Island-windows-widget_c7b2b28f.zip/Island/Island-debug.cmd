@echo off
title Island diagnostics
echo ==================================================
echo  ISLAND - diagnostics
echo ==================================================
echo.
echo [1/3] environment check ...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Write-Host ('  PowerShell ' + $PSVersionTable.PSVersion); Write-Host ('  apartment  ' + [Threading.Thread]::CurrentThread.GetApartmentState()); try { Add-Type -AssemblyName PresentationFramework | Out-Null; Write-Host '  WPF        OK' } catch { Write-Host ('  WPF        MISSING - ' + $_.Exception.Message) }"
echo.
echo [2/3] launching island with error output visible
echo       (close the island window to return here) ...
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Island.ps1" debug
echo.
echo [3/3] crash log, if one was written:
if exist "%TEMP%\IslandPS-crash.log" (type "%TEMP%\IslandPS-crash.log") else (echo   none - clean run^)
echo.
pause
