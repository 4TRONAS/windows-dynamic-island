# Island-check.ps1 — full launch diagnostics WITHOUT showing any UI.
# Every check prints [OK] or [!!] so you can tell exactly what is wrong.
$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ScriptFile = Join-Path $root 'Island.ps1'
$TempDir = [IO.Path]::GetTempPath()

function Line($msg, $ok) {
    if ($ok) { Write-Host ('[OK] ' + $msg) -ForegroundColor Green }
    else     { Write-Host ('[!!] ' + $msg) -ForegroundColor Yellow }
}

Write-Host ''
Write-Host '===== ISLAND CHECKLIST ====='

# 1. script file present
$found = Test-Path -LiteralPath $ScriptFile
Line ('Island.ps1 found: ' + $ScriptFile) $found
if (-not $found) { Write-Host 'Extract the WHOLE zip first (right-click -> Extract All), then run this again.' -ForegroundColor Red; exit 1 }

# 2. execution policies
$pol = ''
try { $pol = [string](Get-ExecutionPolicy) } catch { $pol = 'unknown' }
$blocked = $false
try {
    foreach ($sc in @('MachinePolicy', 'UserPolicy')) {
        $v = [string](Get-ExecutionPolicy -Scope $sc)
        if ($v -eq 'AllSigned' -or $v -eq 'Restricted') { $blocked = $true; $pol += (' (' + $sc + '=' + $v + ' => BLOCKED)') }
    }
} catch { }
Line ('execution policy: ' + $pol) (-not $blocked)

# 3. language mode (AppLocker / WDAC show up here)
$lm = [string]$ExecutionContext.SessionState.LanguageMode
Line ('language mode: ' + $lm) ($lm -eq 'FullLanguage')
if ($lm -ne 'FullLanguage') { Write-Host '     -> security policy blocks PowerShell scripting here (IT policy, not the app).' -ForegroundColor Red }

# 4. WPF assemblies
$wpfOK = $true
try { Add-Type -AssemblyName PresentationFramework; Add-Type -AssemblyName PresentationCore; Add-Type -AssemblyName WindowsBase }
catch { $wpfOK = $false; Line ('WPF assemblies: ' + $_.Exception.Message) $false }
if ($wpfOK) { Line 'WPF assemblies load fine' $true }

# 5. syntax with the SAME parser that will execute the script
$errors = $null
$null = [System.Management.Automation.Language.Parser]::ParseFile($ScriptFile, [ref]$null, [ref]$errors)
if ($errors -and $errors.Count -gt 0) {
    Line ('syntax errors: ' + $errors.Count) $false
    $errors | Select-Object -First 5 | ForEach-Object { Write-Host ('     line ' + $_.Extent.StartLineNumber + ': ' + $_.Message) -ForegroundColor Red }
} else { Line 'Island.ps1 has zero syntax errors' $true }

# 6. XAML — real WPF object-creation test (property names, types, structure)
$txt = [IO.File]::ReadAllText($ScriptFile)
$i = $txt.IndexOf(( '$script:Xaml = @' ))
if ($i -lt 0) { Line 'could not locate the XAML block inside Island.ps1' $false }
else {
    $k = $i
    while ($k -lt $txt.Length -and $txt[$k] -ne "`n") { $k++ }        # past the @' opening line
    $q = [char]39
    $j = $txt.IndexOf([string]$q + '@', $k + 1)                        # the '@ terminator
    $xaml = $txt.Substring($k + 1, $j - $k - 1)
    try {
        $w = [System.Windows.Markup.XamlReader]::Parse($xaml)
        Line ('XAML builds a live WPF ' + ( [string]$w.GetType().Name ) + ' OK') $true
    } catch {
        Line ('XAML FAILED: ' + $_.Exception.Message) $false
    }
}

# 7. stale instances holding the single-instance lock
try {
    $procs = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -EA SilentlyContinue |
               Where-Object { $_.CommandLine -match 'Island\.ps1' -and $_.ProcessId -ne $PID })
    if ($procs.Count -gt 0) {
        Line ($procs.Count.ToString() + ' other Island process(es) running: PID ' + (($procs | ForEach-Object { [string]$_.ProcessId }) -join ', ')) $false
        Write-Host '     fix:  Island.cmd kill    (then start again)' -ForegroundColor Cyan
    } else { Line 'no stale island processes' $true }
} catch { Line 'could not enumerate processes' $false }

# 8. logs from previous attempts
$crash = Join-Path $TempDir 'IslandPS-crash.log'
$boot  = Join-Path $TempDir 'IslandPS-boot.log'
if (Test-Path -LiteralPath $crash) {
    Write-Host '----- last crash ----' -ForegroundColor DarkGray
    Get-Content -LiteralPath $crash -Tail 8 | ForEach-Object { Write-Host ('  ' + $_) -ForegroundColor Yellow }
}
if (Test-Path -LiteralPath $boot) {
    Write-Host '----- recent launch trace ----' -ForegroundColor DarkGray
    Get-Content -LiteralPath $boot -Tail 8 | ForEach-Object { Write-Host ('  ' + $_) -ForegroundColor Gray }
    Write-Host '  (boot only, no shown  =  crashed between start and first frame - see crash log above)' -ForegroundColor DarkGray
}
if (-not (Test-Path -LiteralPath $boot)) {
    Write-Host 'No boot log at all -> powershell itself never ran the script (zip not extracted / policy / AV).' -ForegroundColor Red
}

Write-Host '========================='
Write-Host 'If everything is [OK] but no island appears, run:  Island-debug.cmd'
