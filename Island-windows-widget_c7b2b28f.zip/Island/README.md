# ISLAND — a Dynamic Island for Windows

A floating, always-on-top system companion in **one PowerShell file**. Zero
install, zero admin, zero dependencies — it runs on stock Windows 10 / 11.
Rainmeter's Illustro was 2006's answer; this is today's.

![collapsed pill](docs/island-pill.png)
![expanded](docs/island.png)

## Run it (READ THIS FIRST)

1. **Extract the zip** — right-click → *Extract All*. Never run from inside the
   archive; nothing will appear and you'll get no error.
2. Double-click **`Island.cmd`**. Done — a glass pill drops in top-center.

If it ever refuses to appear:

| Try | What it does |
|---|---|
| **`Island-check.cmd`** | no UI needed: environment, syntax + full XAML test, stale processes, previous logs — every problem prints as [!!] with the fix |
| **`Island-debug.cmd`** | prints environment + every error on screen, tails the crash log |
| **`Island.cmd kill`** | kills stale hidden instances that hold the single-instance lock |
| `%TEMP%\IslandPS-crash.log` | every launch failure is now logged here (dialog pops too) |

> SmartScreen "unknown publisher" → *More info → Run anyway*.
> Corporate laptop? A PowerShell-blocking policy (AppLocker/WDAC/AV) will stop
> any script — `Island-debug.cmd` tells you if that's the case (`constrained
> language` = company policy, not a bug).

## What it does

**LIVE VITALS** — CPU (sparkline + cores + model), memory, network ↓/↑ (dual
sparkline), storage (free/used + read/write + busy), power, uptime, GPU +
resolution, thermal zone temp when firmware exposes it. Green→amber→red, live.

**LAUNCHERS — drag & drop** — drag any desktop shortcut (`.lnk`, `.url`, `.exe`)
**onto the island** — or press `+` to browse. It's pinned with its real icon.
One click launches it. Right-click a tile → unpin.

**SNAPS — 2-hour screenshot memory** — every PrtScn / Win+Shift+S you take
shows as a thumbnail row inside the island. Click opens it, `open with…` lets
you choose the app, copy puts it on the clipboard. Anything older than 2 hours
is **auto-recycled to the Recycle Bin** (never permanently deleted; can be
turned off in the right-click menu).

**CLIPBOARD SHELF** — silently remembers the last ~12 things you copied:
text, links, and **images** (rendered as thumbnails). Click = back on the
clipboard · **double-click = pastes straight into whatever app has focus** ·
right-click = paste/copy/forget.

**HARDWARE ALERTS** — the pill glows amber and toasts you when:
* battery ≤ 20% then critical ≤ 5% (and again when still unplugged)
* C: drive below 8 GB free
* memory exhausted, cpu package ≥ 92 °C
* Windows reports SMART / disk / NTFS health events
The ALERT chip cycles through alert history.

**THE PARTY TRICK — external notifications:**

```bat
Island.cmd "Build 214 passed - 41s"
npm test && Island.cmd "tests green"
terraform apply; Island.cmd "infra drift checked"
```

…so every script, CI job or agent on your machine can talk to your desktop
with one line.

## Interaction cheat-sheet

| Do | Get |
|---|---|
| hover / tap pill | bloom open / pin open |
| drag anywhere | reposition (right-click → re-dock centers it) |
| `Alt+I` | toggle from the keyboard |
| `Esc` | collapse |
| right-click | 7 accents, opacity, autostart, hover-open, topmost, shelf utils |
| vitals tile click | Task Manager / adapters / settings for that subsystem |

## Notes for your next project (integration)

The engine is deliberately separable: PART 2.5 of `Island.ps1` contains the
`Add-Launcher` / `Update-Screenshots` / `Grab-ClipboardNow` / `Raise-Alert`
functions and the `Show-Toast` bus — lift those straight into any WPF or even
WinUI project and keep the same behavior. The notification protocol is just
one appended UTF-8 line (`time|message`) to `%TEMP%\IslandPS\queue.txt`, so
any language can produce island toasts. Settings persist to
`settings.json` beside it.

## Files

| File | Purpose |
|---|---|
| `Island.ps1` | the whole app (~1,800 lines: UI, animation, data engine, shelves) |
| `Island-check.ps1 / .cmd` | no-UI diagnostics: proves what stops a launch |
| `Island.cmd` | launcher · notifier · `kill` · `debug` |
| `Island-debug.cmd` | diagnostics: env check + visible trace + crash log |
| `Island-silent.vbs` | console-less autostart helper |
| `index.html` | live browser preview of the design (simulated data) |

Built in a single session with QwenWork · Alibaba Cloud workshop demo.
