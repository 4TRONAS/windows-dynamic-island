# ============================================================================
#  ISLAND  ·  a Dynamic-Island-style system monitor for Windows 10 / 11
#
#  Rainmeter-quality live vitals (CPU · Memory · Network · Storage · Power ·
#  GPU · Uptime · Temp) inside one floating glass pill that blooms open
#  the moment you hover it — like the Dynamic Island, native on Windows.
#
#  Zero install · zero admin · zero dependencies (pure PowerShell + WPF).
#
#    run        Island.vbs                     (or double-click Island.cmd)
#    notify     Island.cmd "Deploy finished"   (toast pushed into the island)
#    anchored   Island.cmd --anchor-x 960 --anchor-y 8
#
#  Built in a single session with QwenWork · Alibaba Cloud workshop demo.
# ============================================================================

param(
    [string]$Notify,
    [switch]$Minimized,
    [switch]$DebugMode,
    [switch]$Kill,           # stop any other Island instances first
    [double]$AnchorX = -1,
    [double]$AnchorY = -1,
    [switch]$Once          # smoke test: start, render, auto-exit after 4s
)
# 'debug' as a bare token arrives as the first positional ($Notify) in -File mode
if ($Notify -and $Notify.Trim() -match '^(debug|-?debugmode)$') { $Notify = ''; $DebugMode = $true }

# ---------------------------------------------------------- launch guard ---
$ErrorActionPreference = 'Stop'
$script:CrashLog = Join-Path $env:TEMP 'IslandPS-crash.log'
$script:Debug    = [bool]$DebugMode

if ($Kill) {
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -EA SilentlyContinue |
        Where-Object { $_.CommandLine -match 'Island\.ps1' -and $_.ProcessId -ne $PID } |
        ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -EA SilentlyContinue } catch { } }
    Write-Host 'other island instances killed'
    exit 0
}

# WPF requires an STA thread. pwsh 7 defaults to MTA -> relaunch correctly
# instead of dying with a confusing dispatcher error.
if ([System.Threading.Thread]::CurrentThread.GetApartmentState() -ne [System.Threading.ApartmentState]::STA) {
    $self = $PSCommandPath; if (-not $self) { $self = $MyInvocation.MyCommand.Path }
    try {
        $null = Start-Process -FilePath 'powershell.exe' -WindowStyle Hidden -ArgumentList @(
            '-NoProfile', '-ExecutionPolicy', 'Bypass', '-STA', '-File', ('"{0}"' -f $self), '-Minimized'
        )
    } catch { }
    exit 0
}

function Log-Crash($errObj, $extra) {
    try {
        $head = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        "$head  $($errObj)  $extra" | Add-Content -LiteralPath $script:CrashLog -Encoding UTF8
    } catch { }
}
try {
    ('{0}  boot    pid {1}  ps {2}  apt {3}' -f (Get-Date -Format 'HH:mm:ss'), $PID,
        $PSVersionTable.PSVersion, [Threading.Thread]::CurrentThread.GetApartmentState()) |
        Add-Content -LiteralPath (Join-Path $env:TEMP 'IslandPS-boot.log') -Encoding UTF8
} catch { }

# WPF GPU compositor (milcore) dies on several Intel/AMD driver stacks and
# after resume - UCEERR_RENDERTHREADFAILURE = black/ghost/missing windows.
# A floating 600px dashboard does not need the GPU; render 100% in software.
try {
    [System.Windows.Interop.RenderOptions]::ProcessRenderMode = [System.Windows.Interop.RenderMode]::SoftwareOnly
} catch { Log-Crash 'rendermode' $_.Exception.Message }

trap {
    $line = ('{0}  line {1}: {2}' -f (Get-Date -Format 'HH:mm:ss'), $_.InvocationInfo.ScriptLineNumber, $_.Exception.Message)
    try { Set-Content -LiteralPath $script:CrashLog -Value ($line + "`r`n" + $_.ScriptStackTrace) -Encoding UTF8 } catch { }
    Write-Host ('ISLAND CRASH -> ' + $script:CrashLog) -ForegroundColor Red
    Write-Host $line -ForegroundColor Yellow
    if ($script:Debug) { Read-Host 'press Enter to close' | Out-Null }
    else { try { [void][System.Windows.MessageBox]::Show("Island stopped unexpectedly.`r`n`r`n$line`r`n`r`nDetails: $script:CrashLog", 'Island') } catch { } }
    exit 1
}

# ---------------------------------------------------------------- paths ----
$script:AppDir    = Join-Path $env:TEMP 'IslandPS'
if (-not (Test-Path $script:AppDir)) { $null = New-Item -ItemType Directory -Path $script:AppDir }
$script:QueueFile = Join-Path $script:AppDir 'queue.txt'
$script:ConfFile  = Join-Path $script:AppDir 'settings.json'
$script:MutexName = 'Local\IslandPS_Instance'

function Test-IslandRunning {
    try {
        $m = [System.Threading.Mutex]::OpenExisting($script:MutexName)
        $m.Dispose()
        return $true
    } catch { return $false }
}

# ------------------------------------------------- notification sender -----
if ($Notify) {
    $msg = ($Notify -replace "[\r\n|]", ' ').Trim()
    $line = (Get-Date).ToString('HH:mm:ss') + '|' + $msg
    Add-Content -LiteralPath $script:QueueFile -Value $line -Encoding UTF8
    if (-not (Test-IslandRunning)) {
        $self = if ($PSCommandPath) { $PSCommandPath } else { $MyInvocation.MyCommand.Path }
        $null = Start-Process -FilePath 'powershell.exe' -WindowStyle Hidden -ArgumentList @(
            '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $self), '-Minimized'
        )
    }
    Write-Host ("island <- {0}" -f $msg)
    exit 0
}

# ------------------------------------------------------ single instance ----
$script:Mutex = New-Object System.Threading.Mutex($false, $script:MutexName)
$acquired = $false
try   { $acquired = $script:Mutex.WaitOne(0) }
catch [System.Threading.AbandonedMutexException] { $acquired = $true }   # a crashed holder: adopt ownership
if (-not $acquired) {
    if ($Notify) { exit 0 }
    # self-heal: a previous attempt may have left a zombie holding the mutex.
    try {
        Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -EA SilentlyContinue |
            Where-Object { $_.CommandLine -match 'Island\.ps1' -and $_.ProcessId -ne $PID } |
            ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -EA SilentlyContinue } catch { } }
    } catch { }
    Start-Sleep -Milliseconds 600
    try   { $acquired = $script:Mutex.WaitOne(2500) }
    catch [System.Threading.AbandonedMutexException] { $acquired = $true }
    if (-not $acquired) {
        Write-Host 'Island is already running (lock did not clear).'
        exit 0
    }
}

# ------------------------------------------------------------------- WPF ---
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Xaml, System.Windows.Forms, System.Drawing

Add-Type @"
using System;
using System.Runtime.InteropServices;
namespace Island {
    public static class Native {
        [StructLayout(LayoutKind.Sequential)]
        public struct PowerStatus {
            public byte ACLineStatus; public byte BatteryFlag; public byte BatteryLifePercent;
            public byte SystemStatus; public int BatteryLifeTime; public int BatteryFullLifeTime;
        }
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetSystemPowerStatus(out PowerStatus s);
        public static PowerStatus Power() { PowerStatus s; GetSystemPowerStatus(out s); return s; }
    }
}
"@

# ----------------------------------------------------------------------------
# XAML
# ----------------------------------------------------------------------------
$script:Xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Island"
        WindowStyle="None" AllowsTransparency="True" Background="Transparent"
        Topmost="True" ShowInTaskbar="False" ResizeMode="NoResize" AllowDrop="True"
        WindowStartupLocation="Manual" ShowActivated="False"
        Width="254" Height="46" Opacity="0"
        TextOptions.TextFormattingMode="Ideal"
        FontFamily="Segoe UI Variable Text, Segoe UI" UseLayoutRounding="True">
  <Window.Resources>
    <SolidColorBrush x:Key="Ink1" Color="#F3F4F6"/>
    <SolidColorBrush x:Key="Ink2" Color="#959BA5"/>
    <SolidColorBrush x:Key="Ink3" Color="#7B818C"/>
    <SolidColorBrush x:Key="Hair" Color="#17FFFFFF"/>
    <SolidColorBrush x:Key="Fill" Color="#0EFFFFFF"/>
    <SolidColorBrush x:Key="Meter" Color="#C8CBD2"/>

    <Style x:Key="RowS" TargetType="Border">
      <Setter Property="Height" Value="50"/>
      <Setter Property="Background" Value="Transparent"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="BorderBrush" Value="{StaticResource Hair}"/>
      <Setter Property="BorderThickness" Value="0,0.5,0,0.5"/>
      <Style.Triggers>
        <Trigger Property="IsMouseOver" Value="True">
          <Setter Property="Background" Value="#0CFFFFFF"/>
        </Trigger>
      </Style.Triggers>
    </Style>
    <Style x:Key="LettS" TargetType="TextBlock">
      <Setter Property="FontFamily" Value="Segoe UI Variable Display, Segoe UI"/>
      <Setter Property="Typography.NumeralAlignment" Value="Tabular"/>
    </Style>

    <Style x:Key="SldS" TargetType="Slider">
      <Setter Property="Focusable" Value="False"/>
      <Setter Property="IsMoveToPointEnabled" Value="True"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Slider">
            <Grid Height="16" VerticalAlignment="Center">
              <Border Height="2" CornerRadius="1" Background="#2A2D33" VerticalAlignment="Center"/>
              <Track x:Name="PART_Track">
                <Track.DecreaseRepeatButton>
                  <RepeatButton Focusable="False" IsTabStop="False">
                    <RepeatButton.Template>
                      <ControlTemplate TargetType="RepeatButton"><Border Height="2" CornerRadius="1" Background="#8E939C"/></ControlTemplate>
                    </RepeatButton.Template>
                  </RepeatButton>
                </Track.DecreaseRepeatButton>
                <Track.IncreaseRepeatButton>
                  <RepeatButton Focusable="False" IsTabStop="False">
                    <RepeatButton.Template>
                      <ControlTemplate TargetType="RepeatButton"><Border Background="Transparent"/></ControlTemplate>
                    </RepeatButton.Template>
                  </RepeatButton>
                </Track.IncreaseRepeatButton>
                <Track.Thumb>
                  <Thumb Width="13" Height="13" OverridesDefaultStyle="True">
                    <Thumb.Template>
                      <ControlTemplate TargetType="Thumb"><Ellipse Fill="#EAECEF"/></ControlTemplate>
                    </Thumb.Template>
                  </Thumb>
                </Track.Thumb>
              </Track>
            </Grid>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
    <Style x:Key="SldDecS" TargetType="RepeatButton">
      <Setter Property="IsTabStop" Value="False"/>
      <Setter Property="Focusable" Value="False"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="RepeatButton"><Border Height="2" CornerRadius="1" Background="#8E939C"/></ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
    <Style x:Key="SldIncS" TargetType="RepeatButton">
      <Setter Property="IsTabStop" Value="False"/>
      <Setter Property="Focusable" Value="False"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="RepeatButton"><Border Height="2" CornerRadius="1" Background="#2A2D33"/></ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
  </Window.Resources>

  <Border x:Name="Card" CornerRadius="23" BorderBrush="{StaticResource Hair}" BorderThickness="0.5"
          Margin="1">
    <Border.Background>
      <LinearGradientBrush StartPoint="0,0" EndPoint="0,1">
        <GradientStop Color="#FA121316" Offset="0"/>
        <GradientStop Color="#FC0A0B0D" Offset="1"/>
      </LinearGradientBrush>
    </Border.Background>
    <Grid Margin="18,12">

      <!-- ================== PILL (collapsed) ================== -->
      <Grid x:Name="PillView" Background="Transparent">
        <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" VerticalAlignment="Center">
          <Ellipse x:Name="PulseDot" Width="7" Height="7" Fill="#DDE0E4" Margin="0,0,12,0"/>
          <TextBlock x:Name="PillClock" Text="00:00" FontSize="16" FontWeight="SemiBold" Foreground="{StaticResource Ink1}"
                     FontFamily="Segoe UI Variable Display, Segoe UI" Typography.NumeralAlignment="Tabular" Margin="0,0,2,0"/>
          <TextBlock x:Name="PillDate" Visibility="Collapsed"/>
          <Border Width="0.5" Height="18" Background="{StaticResource Hair}" Margin="13,0"/>
          <StackPanel Orientation="Horizontal" VerticalAlignment="Center">
            <StackPanel Width="42" Margin="0,0,10,0">
              <TextBlock x:Name="CpuPillVal" Text="0%" Style="{StaticResource LettS}" FontSize="10" Foreground="{StaticResource Ink2}" HorizontalAlignment="Right"/>
              <Border Height="1.5" Background="#22FFFFFF" Margin="0,4,0,0">
                <Border x:Name="CpuPillBar" Height="1.5" HorizontalAlignment="Left" Width="0" Background="{StaticResource Meter}"/>
              </Border>
            </StackPanel>
            <StackPanel Width="42">
              <TextBlock x:Name="RamPillVal" Text="0%" Style="{StaticResource LettS}" FontSize="10" Foreground="{StaticResource Ink2}" HorizontalAlignment="Right"/>
              <Border Height="1.5" Background="#22FFFFFF" Margin="0,4,0,0">
                <Border x:Name="RamPillBar" Height="1.5" HorizontalAlignment="Left" Width="0" Background="{StaticResource Meter}"/>
              </Border>
            </StackPanel>
          </StackPanel>
          <StackPanel x:Name="PodNet" Visibility="Collapsed" Orientation="Horizontal">
            <TextBlock x:Name="NetDownPill"/><TextBlock x:Name="NetUpPill"/>
          </StackPanel>
          <StackPanel x:Name="PodBattery" Orientation="Horizontal" Visibility="Collapsed" Margin="12,2,0,0">
            <TextBlock x:Name="BatteryPillVal" Text="100%" FontSize="11" Foreground="{StaticResource Ink2}" Typography.NumeralAlignment="Tabular" FontFamily="Segoe UI Variable Display, Segoe UI"/>
            <TextBlock x:Name="BatteryPillState" Text="" FontSize="10" Margin="4,1,0,0" Foreground="{StaticResource Ink2}"/>
          </StackPanel>
        </StackPanel>
      </Grid>

      <!-- ================== EXPANDED ================== -->
      <Grid x:Name="FullView" Visibility="Collapsed" Opacity="0" Background="Transparent">
        <Grid.RowDefinitions>
          <RowDefinition Height="Auto"/>
          <RowDefinition Height="Auto"/>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>

        <!-- header -->
        <Grid Grid.Row="0" x:Name="HeaderZone" Margin="2,0,2,14" Cursor="SizeAll" Background="Transparent">
          <StackPanel Orientation="Horizontal" VerticalAlignment="Bottom">
            <TextBlock x:Name="BigClock" Text="00:00" FontSize="24" FontWeight="SemiBold" Foreground="{StaticResource Ink1}"
                       FontFamily="Segoe UI Variable Display, Segoe UI" Typography.NumeralAlignment="Tabular"/>
            <TextBlock x:Name="BigDate" Text="" FontSize="11" Foreground="{StaticResource Ink3}" Margin="11,0,0,7" MaxWidth="150" TextTrimming="CharacterEllipsis"/>
          </StackPanel>
          <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" VerticalAlignment="Bottom">
            <Border x:Name="BtnGear" Width="24" Height="24" CornerRadius="7" Margin="0,0,8,1" Cursor="Hand" ToolTip="Settings"
                    Background="{StaticResource Fill}">
              <TextBlock Text="&#xE713;" FontSize="12" FontFamily="Segoe Fluent Icons, Segoe MDL2 Assets" Foreground="#C6CDD7"
                         HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <Border Background="{StaticResource Fill}" CornerRadius="6" Padding="8,2" Margin="0,0,6,4">
              <TextBlock x:Name="TxtHost" Text="PC" FontSize="9.5" Foreground="{StaticResource Ink2}"/>
            </Border>
            <Border Background="{StaticResource Fill}" CornerRadius="6" Padding="8,2" Margin="0,0,0,4">
              <TextBlock x:Name="TxtOs" Text="Windows" FontSize="9.5" Foreground="{StaticResource Ink2}"/>
            </Border>
            <TextBlock x:Name="TxtIp" Visibility="Collapsed"/>
          </StackPanel>
        </Grid>

        <!-- nav bar for detail pages -->
        <Grid Grid.Row="1" x:Name="BackStrip" Visibility="Collapsed" Height="26" Margin="0,0,0,8">
          <Border x:Name="BtnBack" HorizontalAlignment="Left" Padding="2,2" Cursor="Hand">
            <TextBlock Text="&#8249;  Island" FontSize="12" Foreground="{StaticResource Ink2}"/>
          </Border>
          <TextBlock x:Name="TxtPageTitle" Text="" FontSize="11.5" FontWeight="SemiBold" Foreground="{StaticResource Ink2}"
                     HorizontalAlignment="Center" VerticalAlignment="Center"/>
        </Grid>

        <!-- ============ HOME ============ -->
        <Grid Grid.Row="2" x:Name="PageGroups">
          <ScrollViewer x:Name="HomeScroll" Focusable="False" VerticalScrollBarVisibility="Hidden">
            <StackPanel x:Name="HomeList">
            <Border Style="{StaticResource RowS}" x:Name="TileGStats">
              <Grid>
                <Grid.ColumnDefinitions><ColumnDefinition Width="34"/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="14"/></Grid.ColumnDefinitions>
                <Border Grid.Column="0" Width="24" Height="24" CornerRadius="6" Background="{StaticResource Fill}">
                  <TextBlock Text="S" FontSize="11" FontWeight="SemiBold" Foreground="#C9CDD4" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <TextBlock Grid.Column="1" Text="System" FontSize="13" FontWeight="Medium" Foreground="{StaticResource Ink1}" VerticalAlignment="Center" Margin="10,0,0,0"/>
                <TextBlock Grid.Column="2" x:Name="GStatsPrev" Text="" FontSize="11.5" Foreground="{StaticResource Ink2}" Opacity="0.85" VerticalAlignment="Center" TextTrimming="CharacterEllipsis" HorizontalAlignment="Right" Margin="12,0,0,0"/>
                <Path Data="M 0 0 L 4.5 4.75 L 0 9.5" Stroke="#29FFFFFF" StrokeThickness="1.2" StrokeStartLineCap="Round" StrokeEndLineCap="Round" StrokeLineJoin="Round" VerticalAlignment="Center"/>

              </Grid>
            </Border>
            <Border Style="{StaticResource RowS}" x:Name="TileGClip">
              <Grid>
                <Grid.ColumnDefinitions><ColumnDefinition Width="34"/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="14"/></Grid.ColumnDefinitions>
                <Border Grid.Column="0" Width="24" Height="24" CornerRadius="6" Background="{StaticResource Fill}">
                  <TextBlock Text="C" FontSize="11" FontWeight="SemiBold" Foreground="#C9CDD4" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <TextBlock Grid.Column="1" Text="Clipboard" FontSize="13" FontWeight="Medium" Foreground="{StaticResource Ink1}" VerticalAlignment="Center" Margin="10,0,0,0"/>
                <TextBlock Grid.Column="2" x:Name="GClipPrev" Text="" FontSize="11.5" Foreground="{StaticResource Ink2}" Opacity="0.85" VerticalAlignment="Center" TextTrimming="CharacterEllipsis" HorizontalAlignment="Right" Margin="12,0,0,0"/>
                <Path Data="M 0 0 L 4.5 4.75 L 0 9.5" Stroke="#29FFFFFF" StrokeThickness="1.2" StrokeStartLineCap="Round" StrokeEndLineCap="Round" StrokeLineJoin="Round" VerticalAlignment="Center"/>

              </Grid>
            </Border>
            <Border Style="{StaticResource RowS}" x:Name="TileGSnaps">
              <Grid>
                <Grid.ColumnDefinitions><ColumnDefinition Width="34"/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="14"/></Grid.ColumnDefinitions>
                <Border Grid.Column="0" Width="24" Height="24" CornerRadius="6" Background="{StaticResource Fill}">
                  <TextBlock Text="P" FontSize="11" FontWeight="SemiBold" Foreground="#C9CDD4" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <TextBlock Grid.Column="1" Text="Snaps" FontSize="13" FontWeight="Medium" Foreground="{StaticResource Ink1}" VerticalAlignment="Center" Margin="10,0,0,0"/>
                <TextBlock Grid.Column="2" x:Name="GSnapsPrev" Text="" FontSize="11.5" Foreground="{StaticResource Ink2}" Opacity="0.85" VerticalAlignment="Center" TextTrimming="CharacterEllipsis" HorizontalAlignment="Right" Margin="12,0,0,0"/>
                <Path Data="M 0 0 L 4.5 4.75 L 0 9.5" Stroke="#29FFFFFF" StrokeThickness="1.2" StrokeStartLineCap="Round" StrokeEndLineCap="Round" StrokeLineJoin="Round" VerticalAlignment="Center"/>

              </Grid>
            </Border>
            <Border Style="{StaticResource RowS}" x:Name="TileGApps">
              <Grid>
                <Grid.ColumnDefinitions><ColumnDefinition Width="34"/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="14"/></Grid.ColumnDefinitions>
                <Border Grid.Column="0" Width="24" Height="24" CornerRadius="6" Background="{StaticResource Fill}">
                  <TextBlock Text="A" FontSize="11" FontWeight="SemiBold" Foreground="#C9CDD4" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <TextBlock Grid.Column="1" Text="Apps" FontSize="13" FontWeight="Medium" Foreground="{StaticResource Ink1}" VerticalAlignment="Center" Margin="10,0,0,0"/>
                <TextBlock Grid.Column="2" x:Name="GAppsPrev" Text="" FontSize="11.5" Foreground="{StaticResource Ink2}" Opacity="0.85" VerticalAlignment="Center" TextTrimming="CharacterEllipsis" HorizontalAlignment="Right" Margin="12,0,0,0"/>
                <Path Data="M 0 0 L 4.5 4.75 L 0 9.5" Stroke="#29FFFFFF" StrokeThickness="1.2" StrokeStartLineCap="Round" StrokeEndLineCap="Round" StrokeLineJoin="Round" VerticalAlignment="Center"/>

              </Grid>
            </Border>
            <Border Style="{StaticResource RowS}" x:Name="TileGRem">
              <Grid>
                <Grid.ColumnDefinitions><ColumnDefinition Width="34"/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="14"/></Grid.ColumnDefinitions>
                <Border Grid.Column="0" Width="24" Height="24" CornerRadius="6" Background="{StaticResource Fill}">
                  <TextBlock Text="R" FontSize="11" FontWeight="SemiBold" Foreground="#C9CDD4" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <TextBlock Grid.Column="1" Text="Reminders" FontSize="13" FontWeight="Medium" Foreground="{StaticResource Ink1}" VerticalAlignment="Center" Margin="10,0,0,0"/>
                <TextBlock Grid.Column="2" x:Name="GRemPrev" Text="" FontSize="11.5" Foreground="{StaticResource Ink2}" Opacity="0.85" VerticalAlignment="Center" TextTrimming="CharacterEllipsis" HorizontalAlignment="Right" Margin="12,0,0,0"/>
                <Path Data="M 0 0 L 4.5 4.75 L 0 9.5" Stroke="#29FFFFFF" StrokeThickness="1.2" StrokeStartLineCap="Round" StrokeEndLineCap="Round" StrokeLineJoin="Round" VerticalAlignment="Center"/>

              </Grid>
            </Border>
                        <Border Style="{StaticResource RowS}" x:Name="TileGFocus">
              <Grid>
                <Grid.ColumnDefinitions><ColumnDefinition Width="34"/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="14"/></Grid.ColumnDefinitions>
                <Border Grid.Column="0" Width="24" Height="24" CornerRadius="6" Background="{StaticResource Fill}">
                  <TextBlock Text="F" FontSize="11" FontWeight="SemiBold" Foreground="#C9CDD4" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <TextBlock Grid.Column="1" Text="Focus" FontSize="13.5" Foreground="#E7E9ED" VerticalAlignment="Center" Margin="11,0,0,0"/>
                <TextBlock Grid.Column="2" x:Name="GFocusPrev" Text="" FontSize="11.5" Foreground="{StaticResource Ink2}" Opacity="0.85" VerticalAlignment="Center" TextTrimming="CharacterEllipsis" HorizontalAlignment="Right" Margin="12,0,0,0"/>
                <Path Grid.Column="3" Data="M 0 0 L 4.5 4.75 L 0 9.5" Stroke="#29FFFFFF" StrokeThickness="1.2" StrokeStartLineCap="Round" StrokeEndLineCap="Round" StrokeLineJoin="Round" VerticalAlignment="Center"/>
              </Grid>
            </Border>
            <Border Style="{StaticResource RowS}" x:Name="TileGAlerts">
              <Grid>
                <Grid.ColumnDefinitions><ColumnDefinition Width="34"/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="14"/></Grid.ColumnDefinitions>
                <Border Grid.Column="0" Width="24" Height="24" CornerRadius="6" Background="{StaticResource Fill}">
                  <TextBlock Text="!" FontSize="11" FontWeight="SemiBold" Foreground="#C9CDD4" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <TextBlock Grid.Column="1" Text="Alerts" FontSize="13" FontWeight="Medium" Foreground="{StaticResource Ink1}" VerticalAlignment="Center" Margin="10,0,0,0"/>
                <TextBlock Grid.Column="2" x:Name="GAlertPrev" Text="" FontSize="11.5" Foreground="{StaticResource Ink2}" Opacity="0.85" VerticalAlignment="Center" TextTrimming="CharacterEllipsis" HorizontalAlignment="Right" Margin="12,0,0,0"/>
                <Path Data="M 0 0 L 4.5 4.75 L 0 9.5" Stroke="#29FFFFFF" StrokeThickness="1.2" StrokeStartLineCap="Round" StrokeEndLineCap="Round" StrokeLineJoin="Round" VerticalAlignment="Center"/>

              </Grid>
            </Border>
            <Border Height="16" Background="Transparent"/><Border Style="{StaticResource RowS}" x:Name="TileGActions" BorderThickness="0,0.5,0,0">
              <Grid>
                <Grid.ColumnDefinitions><ColumnDefinition Width="34"/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="14"/></Grid.ColumnDefinitions>
                <Border Grid.Column="0" Width="24" Height="24" CornerRadius="6" Background="{StaticResource Fill}">
                  <TextBlock Text="T" FontSize="11" FontWeight="SemiBold" Foreground="#C9CDD4" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <TextBlock Grid.Column="1" Text="Actions" FontSize="13" FontWeight="Medium" Foreground="{StaticResource Ink1}" VerticalAlignment="Center" Margin="10,0,0,0"/>
                <TextBlock Grid.Column="2" x:Name="GActionsPrev" Text="" FontSize="11.5" Foreground="{StaticResource Ink2}" Opacity="0.85" VerticalAlignment="Center" TextTrimming="CharacterEllipsis" HorizontalAlignment="Right" Margin="12,0,0,0"/>
                <Path Data="M 0 0 L 4.5 4.75 L 0 9.5" Stroke="#29FFFFFF" StrokeThickness="1.2" StrokeStartLineCap="Round" StrokeEndLineCap="Round" StrokeLineJoin="Round" VerticalAlignment="Center"/>

              </Grid>
            </Border>
            <Border Style="{StaticResource RowS}" x:Name="TileGSet" BorderThickness="0,0.5,0,0">
              <Grid>
                <Grid.ColumnDefinitions><ColumnDefinition Width="34"/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="14"/></Grid.ColumnDefinitions>
                <Border Grid.Column="0" Width="24" Height="24" CornerRadius="6" Background="{StaticResource Fill}">
                  <TextBlock Text="G" FontSize="11" FontWeight="SemiBold" Foreground="#C9CDD4" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <TextBlock Grid.Column="1" Text="Settings" FontSize="13" FontWeight="Medium" Foreground="{StaticResource Ink1}" VerticalAlignment="Center" Margin="10,0,0,0"/>
                <TextBlock Grid.Column="2" x:Name="GSetPrev" Text="" FontSize="11.5" Foreground="{StaticResource Ink3}" VerticalAlignment="Center"/>
                <Path Data="M 0 0 L 4.5 4.75 L 0 9.5" Stroke="#29FFFFFF" StrokeThickness="1.2" StrokeStartLineCap="Round" StrokeEndLineCap="Round" StrokeLineJoin="Round" VerticalAlignment="Center"/>

              </Grid>
            </Border>
            </StackPanel>
          </ScrollViewer>
          <Grid x:Name="HomeGridDock" Width="0" Height="0" Visibility="Collapsed">
            <UniformGrid x:Name="HomeGrid" Rows="4" Columns="2"/>
          </Grid>
          <Border x:Name="HomeFade" Height="20" VerticalAlignment="Bottom" IsHitTestVisible="False">
            <Border.Background>
              <LinearGradientBrush StartPoint="0,0" EndPoint="0,1">
                <GradientStop Color="#000A0B0D" Offset="0"/>
                <GradientStop Color="#F00A0B0D" Offset="1"/>
              </LinearGradientBrush>
            </Border.Background>
          </Border>
        </Grid>

        <!-- ============ STATS ============ -->
        <Grid Grid.Row="2" x:Name="PageStats" Visibility="Collapsed">
          <StackPanel>
            <UniformGrid Rows="2" Columns="2" Margin="0,0,-6,-6">
              <Border x:Name="TileCpu" Margin="0,0,6,6" CornerRadius="14" Background="{StaticResource Fill}" Cursor="Hand">
                <StackPanel Margin="14,11">
                  <TextBlock Text="Processor" FontSize="10.5" Foreground="{StaticResource Ink3}"/>
                  <StackPanel Orientation="Horizontal" Margin="0,2,0,0">
                    <TextBlock x:Name="HeroCpuVal" Text="0" Style="{StaticResource LettS}" FontSize="30" FontWeight="SemiBold" Foreground="{StaticResource Ink1}"/>
                    <TextBlock Text="%" FontSize="13" Foreground="{StaticResource Ink3}" Margin="3,17,0,0"/>
                  </StackPanel>
                  <Border Height="1.5" Background="#22FFFFFF" Margin="0,8,0,0">
                    <Border x:Name="HeroCpuBar" Height="1.5" HorizontalAlignment="Left" Width="0" Background="{StaticResource Meter}"/>
                  </Border>
                  <Canvas x:Name="CpuSpark" Height="26" Margin="0,7,0,0" ClipToBounds="True"/>
                  <TextBlock x:Name="HeroCpuName" Text="" FontSize="9" Foreground="#6A7079" Margin="0,6,0,0" TextTrimming="CharacterEllipsis"/>
                  <TextBlock x:Name="HeroCpuCores" Text="" FontSize="9" Foreground="#565C66" Visibility="Collapsed"/>
                </StackPanel>
              </Border>
              <Border x:Name="TileMem" Margin="0,0,0,6" CornerRadius="14" Background="{StaticResource Fill}" Cursor="Hand">
                <StackPanel Margin="14,11">
                  <TextBlock Text="Memory" FontSize="10.5" Foreground="{StaticResource Ink3}"/>
                  <StackPanel Orientation="Horizontal" Margin="0,2,0,0">
                    <TextBlock x:Name="HeroMemVal" Text="0" Style="{StaticResource LettS}" FontSize="30" FontWeight="SemiBold" Foreground="{StaticResource Ink1}"/>
                    <TextBlock Text="%" FontSize="13" Foreground="{StaticResource Ink3}" Margin="3,17,0,0"/>
                  </StackPanel>
                  <Border Height="1.5" Background="#22FFFFFF" Margin="0,8,0,0">
                    <Border x:Name="HeroMemBar" Height="1.5" HorizontalAlignment="Left" Width="0" Background="{StaticResource Meter}"/>
                  </Border>
                  <Canvas x:Name="MemSpark" Height="26" Margin="0,7,0,0" ClipToBounds="True"/>
                  <TextBlock x:Name="HeroMemGb" Text="" FontSize="9" Foreground="#6A7079" Margin="0,6,0,0"/>
                  <TextBlock x:Name="HeroMemSub" Text="" FontSize="9" Foreground="#565C66" Visibility="Collapsed"/>
                </StackPanel>
              </Border>
              <Border x:Name="TileNet" Margin="0,0,6,0" CornerRadius="14" Background="{StaticResource Fill}" Cursor="Hand">
                <StackPanel Margin="14,11">
                  <TextBlock Text="Network" FontSize="10.5" Foreground="{StaticResource Ink3}"/>
                  <Grid Margin="0,3,0,0">
                    <StackPanel Orientation="Horizontal">
                      <TextBlock Text="&#8595;" FontSize="11" Foreground="{StaticResource Ink3}" Margin="0,13,6,0"/>
                      <TextBlock x:Name="NetDownBig" Text="0" Style="{StaticResource LettS}" FontSize="25" FontWeight="SemiBold" Foreground="{StaticResource Ink1}"/>
                      <TextBlock x:Name="NetDownUnit" Text="B/s" FontSize="10.5" Foreground="{StaticResource Ink3}" Margin="4,14,0,0"/>
                    </StackPanel>
                    <StackPanel Orientation="Horizontal" HorizontalAlignment="Right">
                      <TextBlock Text="&#8593;" FontSize="11" Foreground="{StaticResource Ink3}" Margin="0,13,6,0"/>
                      <TextBlock x:Name="NetUpBig" Text="0" Style="{StaticResource LettS}" FontSize="25" FontWeight="SemiBold" Foreground="{StaticResource Ink2}"/>
                    </StackPanel>
                  </Grid>
                  <Canvas x:Name="NetSpark" Height="30" Margin="0,7,0,0" ClipToBounds="True"/>
                  <TextBlock x:Name="TxtLink" Text="" FontSize="9" Foreground="#6A7079" Margin="0,6,0,0"/>
                </StackPanel>
              </Border>
              <Border x:Name="TileSto" CornerRadius="14" Background="{StaticResource Fill}" Cursor="Hand">
                <StackPanel Margin="14,11">
                  <TextBlock Text="Storage" FontSize="10.5" Foreground="{StaticResource Ink3}"/>
                  <StackPanel Orientation="Horizontal" Margin="0,2,0,0">
                    <TextBlock x:Name="StoVal" Text="0" Style="{StaticResource LettS}" FontSize="30" FontWeight="SemiBold" Foreground="{StaticResource Ink1}"/>
                    <TextBlock Text="% used" FontSize="12" Foreground="{StaticResource Ink3}" Margin="5,17,0,0"/>
                  </StackPanel>
                  <Border Height="1.5" Background="#22FFFFFF" Margin="0,8,0,0">
                    <Border x:Name="StoBar" Height="1.5" HorizontalAlignment="Left" Width="0" Background="{StaticResource Meter}"/>
                  </Border>
                  <TextBlock x:Name="StoFree" Text="" FontSize="9.5" Foreground="#6A7079" Margin="0,9,0,0"/>
                  <TextBlock x:Name="StoAct" Text="" FontSize="9.5" Foreground="#565C66"/>
                </StackPanel>
              </Border>
            </UniformGrid>
            <Border BorderBrush="{StaticResource Hair}" BorderThickness="0,0.5,0,0" Margin="0,14,0,0">
              <Grid Height="42">
                <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="*"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                <Border x:Name="TilePwr" Grid.Column="0" Cursor="Hand" Background="Transparent">
                  <Grid VerticalAlignment="Center"><TextBlock Text="Power" FontSize="10.5" Foreground="{StaticResource Ink3}"/><TextBlock x:Name="PwrVal" Text="--" Style="{StaticResource LettS}" FontSize="12.5" FontWeight="Medium" Foreground="{StaticResource Ink1}" Margin="48,2,0,0"/><TextBlock x:Name="PwrSub" Text="" FontSize="9.5" Foreground="{StaticResource Ink3}" HorizontalAlignment="Right" TextTrimming="CharacterEllipsis"/></Grid>
                </Border>
                <Border Grid.Column="0" Width="0.5" HorizontalAlignment="Left" Background="{StaticResource Hair}"/>
                <Border x:Name="TileSys" Grid.Column="1" Cursor="Hand" Background="Transparent">
                  <Grid VerticalAlignment="Center" Margin="14,0"><TextBlock Text="Up" FontSize="10.5" Foreground="{StaticResource Ink3}"/><TextBlock x:Name="UpVal" Text="--" Style="{StaticResource LettS}" FontSize="12.5" FontWeight="Medium" Foreground="{StaticResource Ink1}" Margin="28,2,0,0"/><TextBlock x:Name="UpSub" Text="" FontSize="10" Foreground="{StaticResource Ink3}" HorizontalAlignment="Right"/></Grid>
                </Border>
                <Border Grid.Column="1" Width="0.5" HorizontalAlignment="Left" Background="{StaticResource Hair}"/>
                <Border x:Name="TileDisp" Grid.Column="2" Cursor="Hand" Background="Transparent">
                  <Grid VerticalAlignment="Center" Margin="14,0,0,0"><TextBlock Text="GPU" FontSize="10.5" Foreground="{StaticResource Ink3}"/><TextBlock x:Name="GpuVal" Text="" FontSize="11" FontWeight="Medium" Foreground="{StaticResource Ink1}" Margin="30,1,0,0" TextTrimming="CharacterEllipsis" MaxWidth="110"/><TextBlock x:Name="ResVal" Text="" FontSize="10" Foreground="{StaticResource Ink3}" HorizontalAlignment="Right"/></Grid>
                </Border>
              </Grid>
            </Border>
          </StackPanel>
        </Grid>

        <!-- ============ CLIP ============ -->
        <Grid Grid.Row="2" x:Name="PageClip" Visibility="Collapsed">
          <Grid>
            <ScrollViewer Focusable="False" VerticalScrollBarVisibility="Hidden" HorizontalScrollBarVisibility="Hidden">
              <StackPanel x:Name="ClipHost" Orientation="Horizontal"/>
            </ScrollViewer>
            <Border x:Name="BtnClearClip" Width="30" Height="30" CornerRadius="9" HorizontalAlignment="Right" VerticalAlignment="Top" Margin="0,0,6,0" Cursor="Hand" Background="{StaticResource Fill}">
              <TextBlock Text="&#215;" FontSize="12" Foreground="{StaticResource Ink2}" HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <TextBlock x:Name="ClipEmptyHint" Text="Nothing copied yet.&#10;It will appear here the moment you do." FontSize="12" Foreground="{StaticResource Ink3}"
                       TextAlignment="Center" HorizontalAlignment="Center" VerticalAlignment="Center"/>
          </Grid>
        </Grid>

        <!-- ============ SNAPS ============ -->
        <Grid Grid.Row="2" x:Name="PageSnaps" Visibility="Collapsed">
          <Grid>
            <ScrollViewer Focusable="False" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Hidden">
              <StackPanel x:Name="ShotHost" Orientation="Horizontal"/>
            </ScrollViewer>
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" VerticalAlignment="Top">
              <TextBlock x:Name="ShotCount" Text="" FontSize="10" Foreground="{StaticResource Ink3}" VerticalAlignment="Center" Margin="0,12,8,0"/>
              <Border x:Name="BtnSnap" Width="30" Height="30" CornerRadius="9" Cursor="Hand" Background="{StaticResource Fill}">
                <TextBlock Text="+" FontSize="14" Foreground="{StaticResource Ink2}" HorizontalAlignment="Center" VerticalAlignment="Center"/>
              </Border>
            </StackPanel>
            <TextBlock x:Name="ShotEmptyHint" Text="No captures in the last two hours.&#10;Press PrtScn, or add one with the button." FontSize="12" Foreground="{StaticResource Ink3}"
                       TextAlignment="Center" HorizontalAlignment="Center" VerticalAlignment="Center"/>
          </Grid>
        </Grid>

        <!-- ============ APPS ============ -->
        <Grid Grid.Row="2" x:Name="PageApps" Visibility="Collapsed">
          <Grid>
            <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
            <ScrollViewer Grid.Row="0" Focusable="False" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Hidden">
              <StackPanel x:Name="LaunchHost" Orientation="Horizontal"/>
            </ScrollViewer>
            <StackPanel Grid.Row="1" Orientation="Horizontal" HorizontalAlignment="Center" Margin="0,14,0,2">
              <Border x:Name="BtnAddLauncher" Width="30" Height="30" CornerRadius="9" Cursor="Hand" Background="{StaticResource Fill}">
                <TextBlock Text="+" FontSize="14" Foreground="{StaticResource Ink2}" HorizontalAlignment="Center" VerticalAlignment="Center"/>
              </Border>
              <TextBlock Text="or drop any shortcut on the island" FontSize="11" Foreground="{StaticResource Ink3}" VerticalAlignment="Center" Margin="10,1,0,0"/>
            </StackPanel>
          </Grid>
        </Grid>

        <!-- ============ ALERTS ============ -->
        <!-- ============ FOCUS ============ -->
        <Grid Grid.Row="2" x:Name="PageFocus" Visibility="Collapsed">
          <StackPanel>
            <Grid Height="212" Margin="0,2,0,0">
              <Canvas Width="200" Height="200" HorizontalAlignment="Center" VerticalAlignment="Center">
                <Ellipse Width="190" Height="190" Canvas.Left="5" Canvas.Top="5" Stroke="#1FFFFFFF" StrokeThickness="3.5"/>
                <Path x:Name="FoArc" Stroke="#E4E6EA" StrokeThickness="3.5" StrokeStartLineCap="Round" StrokeEndLineCap="Round"/>
              </Canvas>
              <StackPanel HorizontalAlignment="Center" VerticalAlignment="Center" Margin="0,0,0,6">
                <TextBlock x:Name="FoBig" Text="25:00" FontSize="46" FontWeight="Light" Foreground="{StaticResource Ink1}"
                           FontFamily="Segoe UI Variable Display, Segoe UI" Typography.NumeralAlignment="Tabular" TextAlignment="Center"/>
                <TextBlock x:Name="FoState" Text="F O C U S" FontSize="8.5" FontWeight="SemiBold" Foreground="{StaticResource Ink3}"
                           TextAlignment="Center" Margin="0,7,0,0"/>
              </StackPanel>
            </Grid>
            <UniformGrid Rows="1" Columns="4" Margin="6,2,6,0">
              <Border x:Name="Fo15" Margin="0,0,6,0" Height="36" CornerRadius="10" Cursor="Hand" Background="{StaticResource Fill}">
                <TextBlock Text="15" FontSize="12" Foreground="{StaticResource Ink2}" TextAlignment="Center" VerticalAlignment="Center" FontFamily="Segoe UI Variable Display, Segoe UI" Typography.NumeralAlignment="Tabular"/>
              </Border>
              <Border x:Name="Fo25" Margin="0,0,6,0" Height="36" CornerRadius="10" Cursor="Hand" Background="{StaticResource Fill}">
                <TextBlock Text="25" FontSize="12" Foreground="{StaticResource Ink2}" TextAlignment="Center" VerticalAlignment="Center" FontFamily="Segoe UI Variable Display, Segoe UI" Typography.NumeralAlignment="Tabular"/>
              </Border>
              <Border x:Name="Fo45" Margin="0,0,6,0" Height="36" CornerRadius="10" Cursor="Hand" Background="{StaticResource Fill}">
                <TextBlock Text="45" FontSize="12" Foreground="{StaticResource Ink2}" TextAlignment="Center" VerticalAlignment="Center" FontFamily="Segoe UI Variable Display, Segoe UI" Typography.NumeralAlignment="Tabular"/>
              </Border>
              <Border x:Name="Fo60" Height="36" CornerRadius="10" Cursor="Hand" Background="{StaticResource Fill}">
                <TextBlock Text="60" FontSize="12" Foreground="{StaticResource Ink2}" TextAlignment="Center" VerticalAlignment="Center" FontFamily="Segoe UI Variable Display, Segoe UI" Typography.NumeralAlignment="Tabular"/>
              </Border>
            </UniformGrid>
            <UniformGrid Rows="1" Columns="2" Margin="6,10,6,0">
              <Border x:Name="FoStart" Height="40" Margin="0,0,6,0" CornerRadius="11" Cursor="Hand" Background="#EAECEF">
                <TextBlock x:Name="FoStartTxt" Text="BEGIN" FontSize="11.5" FontWeight="SemiBold" Foreground="#101214" TextAlignment="Center" VerticalAlignment="Center"/>
              </Border>
              <Border x:Name="FoReset" Height="40" CornerRadius="11" Cursor="Hand" Background="{StaticResource Fill}">
                <TextBlock Text="RESET" FontSize="11.5" FontWeight="SemiBold" Foreground="{StaticResource Ink2}" TextAlignment="Center" VerticalAlignment="Center"/>
              </Border>
            </UniformGrid>
            <TextBlock Text="the live bar shows the countdown while you're away" FontSize="9.5" Foreground="#4B515C" TextAlignment="Center" Margin="0,11,0,0"/>
          </StackPanel>
        </Grid>

        <Grid Grid.Row="2" x:Name="PageAlerts" Visibility="Collapsed">
          <Grid>
            <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
            <ScrollViewer Grid.Row="0" Focusable="False" VerticalScrollBarVisibility="Auto">
              <StackPanel x:Name="AlertHost"/>
            </ScrollViewer>
            <Border Grid.Row="1" x:Name="BtnAlertSeen" HorizontalAlignment="Right" Margin="0,8,2,0" Padding="12,5" Cursor="Hand"
                    BorderBrush="{StaticResource Hair}" BorderThickness="0.5" CornerRadius="7">
              <TextBlock Text="Mark seen" FontSize="11" Foreground="{StaticResource Ink2}"/>
            </Border>
          </Grid>
        </Grid>

        <!-- ============ REMINDERS ============ -->
        <Grid Grid.Row="2" x:Name="PageReminders" Visibility="Collapsed">
          <Grid>
            <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
            <ScrollViewer Grid.Row="0" Focusable="False" VerticalScrollBarVisibility="Auto">
              <StackPanel x:Name="RemindHost"/>
            </ScrollViewer>
            <Border Grid.Row="1" x:Name="BtnAddReminder" HorizontalAlignment="Left" Margin="0,10,0,2" Padding="12,5" Cursor="Hand"
                    BorderBrush="{StaticResource Hair}" BorderThickness="0.5" CornerRadius="7">
              <TextBlock Text="+  New reminder" FontSize="11" Foreground="{StaticResource Ink2}"/>
            </Border>
          </Grid>
        </Grid>

        <!-- ============ ACTIONS ============ -->
        <Grid Grid.Row="2" x:Name="PageActions" Visibility="Collapsed">
          <UniformGrid Rows="4" Columns="2" Margin="0,0,0,0">
            <Border x:Name="A_taskmgr" Style="{StaticResource RowS}" Margin="0,0,6,0" Height="44">
              <StackPanel Orientation="Horizontal" VerticalAlignment="Center" Margin="8,0">
                <TextBlock Text="Task Manager" FontSize="12" Foreground="{StaticResource Ink1}"/>
              </StackPanel>
            </Border>
            <Border x:Name="A_capture" Style="{StaticResource RowS}" Margin="6,0,0,0" Height="44">
              <TextBlock Text="Capture Screen" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center" Margin="8,0"/>
            </Border>
            <Border x:Name="A_clippage" Style="{StaticResource RowS}" Margin="0,0,6,0" Height="44">
              <TextBlock Text="Clipboard" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center" Margin="8,0"/>
            </Border>
            <Border x:Name="A_apppage" Style="{StaticResource RowS}" Margin="6,0,0,0" Height="44">
              <TextBlock Text="Add an App" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center" Margin="8,0"/>
            </Border>
            <Border x:Name="A_net" Style="{StaticResource RowS}" Margin="0,0,6,0" Height="44">
              <TextBlock Text="Adapters" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center" Margin="8,0"/>
            </Border>
            <Border x:Name="A_batt" Style="{StaticResource RowS}" Margin="6,0,0,0" Height="44">
              <TextBlock Text="Battery" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center" Margin="8,0"/>
            </Border>
            <Border x:Name="A_color" Style="{StaticResource RowS}" Margin="0,0,6,0" Height="44">
              <TextBlock Text="Cycle Accent" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center" Margin="8,0"/>
            </Border>
            <Border x:Name="A_restart" Style="{StaticResource RowS}" Margin="6,0,0,0" Height="44" BorderThickness="0,0.5,0,0">
              <TextBlock Text="Restart Island" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center" Margin="8,0"/>
            </Border>
          </UniformGrid>
        </Grid>

        <!-- ============ SETTINGS ============ -->
        <Grid Grid.Row="2" x:Name="PageSettings" Visibility="Collapsed">
          <ScrollViewer Focusable="False" VerticalScrollBarVisibility="Auto">
            <StackPanel>
              <TextBlock Text="Behavior" FontSize="11" Foreground="{StaticResource Ink3}" Margin="4,2,0,8"/>
              <Border x:Name="ST_hover" Style="{StaticResource RowS}" Height="44">
                <Grid Margin="8,0"><TextBlock Text="Hover to open" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center"/><TextBlock x:Name="V_hover" Text="--" FontSize="11" Foreground="{StaticResource Ink3}" HorizontalAlignment="Right" VerticalAlignment="Center"/></Grid>
              </Border>
              <Border x:Name="ST_full" Style="{StaticResource RowS}" Height="44">
                <Grid Margin="8,0"><TextBlock Text="Hide in fullscreen" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center"/><TextBlock x:Name="V_full" Text="--" FontSize="11" Foreground="{StaticResource Ink3}" HorizontalAlignment="Right" VerticalAlignment="Center"/></Grid>
              </Border>
              <Border x:Name="ST_layout" Style="{StaticResource RowS}" Height="44">
                <Grid Margin="8,0"><TextBlock Text="Home layout" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center"/><TextBlock x:Name="V_layout" Text="--" FontSize="11" Foreground="{StaticResource Ink3}" HorizontalAlignment="Right" VerticalAlignment="Center"/></Grid>
              </Border>
              <Border x:Name="ST_top" Style="{StaticResource RowS}" Height="44">
                <Grid Margin="8,0"><TextBlock Text="Always on top" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center"/><TextBlock x:Name="V_top" Text="--" FontSize="11" Foreground="{StaticResource Ink3}" HorizontalAlignment="Right" VerticalAlignment="Center"/></Grid>
              </Border>
              <Border x:Name="ST_auto" Style="{StaticResource RowS}" Height="44">
                <Grid Margin="8,0"><TextBlock Text="Launch at sign-in" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center"/><TextBlock x:Name="V_auto" Text="--" FontSize="11" Foreground="{StaticResource Ink3}" HorizontalAlignment="Right" VerticalAlignment="Center"/></Grid>
              </Border>
              <Border x:Name="ST_accent" Style="{StaticResource RowS}" Height="44" BorderThickness="0,0.5,0,0.5">
                <Grid Margin="8,0"><TextBlock Text="Accent" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center"/><TextBlock x:Name="V_accent" Text="--" FontSize="11" Foreground="{StaticResource Ink3}" HorizontalAlignment="Right" VerticalAlignment="Center"/></Grid>
              </Border>
              <TextBlock Text="Appearance" FontSize="11" Foreground="{StaticResource Ink3}" Margin="4,18,0,8"/>
              <StackPanel Margin="8,0">
                <Grid Margin="0,4,0,6">
                  <Grid.ColumnDefinitions><ColumnDefinition Width="112"/><ColumnDefinition Width="*"/><ColumnDefinition Width="42"/></Grid.ColumnDefinitions>
                  <TextBlock Text="Opacity" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center"/>
                  <Slider Grid.Column="1" x:Name="Sld_opaque" Minimum="55" Maximum="100" IsSnapToTickEnabled="True" TickFrequency="1" VerticalAlignment="Center" Focusable="False"
                          Style="{StaticResource SldS}"/>
                  <TextBlock Grid.Column="2" x:Name="V_opaque" Text="--" FontSize="11" Foreground="{StaticResource Ink3}" HorizontalAlignment="Right" VerticalAlignment="Center"/>
                </Grid>
                <Grid Margin="0,4,0,6">
                  <Grid.ColumnDefinitions><ColumnDefinition Width="112"/><ColumnDefinition Width="*"/><ColumnDefinition Width="42"/></Grid.ColumnDefinitions>
                  <TextBlock Text="Island width" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center"/>
                  <Slider Grid.Column="1" x:Name="Sld_width" Minimum="80" Maximum="130" IsSnapToTickEnabled="True" TickFrequency="1" VerticalAlignment="Center" Focusable="False"
                          Style="{StaticResource SldS}"/>
                  <TextBlock Grid.Column="2" x:Name="V_width" Text="--" FontSize="11" Foreground="{StaticResource Ink3}" HorizontalAlignment="Right" VerticalAlignment="Center"/>
                </Grid>
                <Grid Margin="0,4,0,6">
                  <Grid.ColumnDefinitions><ColumnDefinition Width="112"/><ColumnDefinition Width="*"/><ColumnDefinition Width="42"/></Grid.ColumnDefinitions>
                  <TextBlock Text="Motion" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center"/>
                  <Slider Grid.Column="1" x:Name="Sld_speed" Minimum="120" Maximum="600" IsSnapToTickEnabled="True" TickFrequency="10" VerticalAlignment="Center" Focusable="False"
                          Style="{StaticResource SldS}"/>
                  <TextBlock Grid.Column="2" x:Name="V_speed" Text="--" FontSize="11" Foreground="{StaticResource Ink3}" HorizontalAlignment="Right" VerticalAlignment="Center"/>
                </Grid>
                <Grid Margin="0,4,0,0">
                  <Grid.ColumnDefinitions><ColumnDefinition Width="112"/><ColumnDefinition Width="*"/><ColumnDefinition Width="42"/></Grid.ColumnDefinitions>
                  <TextBlock Text="Keep shelf for" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center"/>
                  <Slider Grid.Column="1" x:Name="Sld_retain" Minimum="1" Maximum="12" IsSnapToTickEnabled="True" TickFrequency="1" VerticalAlignment="Center" Focusable="False"
                          Style="{StaticResource SldS}"/>
                  <TextBlock Grid.Column="2" x:Name="V_retain" Text="--" FontSize="11" Foreground="{StaticResource Ink3}" HorizontalAlignment="Right" VerticalAlignment="Center"/>
                </Grid>
              </StackPanel>
              <TextBlock Text="Data" FontSize="11" Foreground="{StaticResource Ink3}" Margin="4,18,0,8"/>
              <Border x:Name="ST_scrub" Style="{StaticResource RowS}" Height="44">
                <Grid Margin="8,0"><TextBlock Text="Auto-clean snaps" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center"/><TextBlock x:Name="V_scrub" Text="--" FontSize="11" Foreground="{StaticResource Ink3}" HorizontalAlignment="Right" VerticalAlignment="Center"/></Grid>
              </Border>
              <Border x:Name="ST_data" Style="{StaticResource RowS}" Height="44">
                <Grid Margin="8,0"><TextBlock Text="Open data folder" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center"/><TextBlock x:Name="V_data" Text="" FontSize="11" Foreground="{StaticResource Ink3}" HorizontalAlignment="Right" VerticalAlignment="Center"/></Grid>
              </Border>
              <Border x:Name="ST_reset" Style="{StaticResource RowS}" Height="44" BorderThickness="0,0.5,0,0">
                <Grid Margin="8,0"><TextBlock Text="Reset everything" FontSize="12" Foreground="{StaticResource Ink1}" VerticalAlignment="Center"/><TextBlock x:Name="V_reset" Text="" FontSize="11" Foreground="{StaticResource Ink3}" HorizontalAlignment="Right" VerticalAlignment="Center"/></Grid>
              </Border>
            </StackPanel>
          </ScrollViewer>
        </Grid>

        <!-- live bar -->
        <Grid Grid.Row="3" x:Name="LiveBar" Margin="0,10,0,0">
          <Border BorderBrush="{StaticResource Hair}" BorderThickness="0,0.5,0,0" Padding="0,8,0,0">
            <Grid>
              <Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
              <StackPanel Grid.Column="0" Orientation="Horizontal">
                <Border x:Name="AlertChip" Visibility="Collapsed" Margin="0,0,8,0" Padding="7,1" CornerRadius="5" BorderThickness="0.5" BorderBrush="#33FFB26B" Cursor="Hand">
                  <StackPanel Orientation="Horizontal">
                    <TextBlock Text="!" FontSize="9" FontWeight="Bold" Foreground="#C2A177"/>
                    <TextBlock x:Name="AlertText" Text="" FontSize="9.5" Foreground="#A38F77" Margin="5,0,0,0"/>
                  </StackPanel>
                </Border>
                <Border x:Name="FeedPill" Grid.Column="1" Background="Transparent" Padding="0" Cursor="Hand" Margin="10,0,0,0" HorizontalAlignment="Left">
                  <TextBlock x:Name="FeedText" Text="" FontSize="10.5" Foreground="#828893" TextTrimming="CharacterEllipsis"/>
                </Border>
              </StackPanel>
              <StackPanel Grid.Column="2" Orientation="Horizontal" HorizontalAlignment="Right" VerticalAlignment="Center">
                <Border x:Name="TempChip" Visibility="Collapsed" Margin="0,0,8,0">
                  <TextBlock x:Name="TempText" Text="" FontSize="10.5" Foreground="{StaticResource Ink3}"/>
                </Border>
                <TextBlock Text="ISLAND" FontSize="8" FontWeight="SemiBold" Foreground="#23262B"/>
              </StackPanel>
            </Grid>
          </Border>
        </Grid>
        <Grid Height="0"/>
        <TextBlock Grid.Row="4" Text="" Height="0"/>
      </Grid>
    </Grid>
  </Border>
</Window>
'@

$window = [System.Windows.Markup.XamlReader]::Parse($script:Xaml)

$script:ui = @{}
foreach ($n in @('Card','PillView','PulseDot','PillClock','PillDate',
                 'CpuPillVal','CpuPillBar','RamPillVal','RamPillBar','NetDownPill','NetUpPill',
                 'PodNet','PodBattery','BatteryPillVal','BatteryPillState',
                 'FullView','HeaderZone','BigClock','BigDate','TxtHost','TxtOs','TxtIp',
                 'TileCpu','HeroCpuName','HeroCpuVal','HeroCpuCores','HeroCpuBar','CpuSpark',
                 'TileMem','HeroMemSub','HeroMemVal','HeroMemGb','HeroMemBar','MemSpark',
                 'TileNet','TxtLink','NetDownBig','NetDownUnit','NetUpBig','NetSpark',
                 'TileSto','StoVal','StoBar','StoFree','StoAct',
                 'TilePwr','PwrVal','PwrSub','TileSys','UpVal','UpSub','TileDisp','GpuVal','ResVal',
                 'BtnAddLauncher','LaunchHost','ShotHost','ShotCount','BtnSnap','ClipHost','BtnClearClip',
                 'AlertChip','AlertText','FeedPill','FeedText','TempChip','TempText',
                 'PageGroups','PageStats','PageClip','PageSnaps','PageApps','PageAlerts','PageActions',
                 'BackStrip','BtnBack','TxtPageTitle','LiveBar','AlertHost','BtnAlertSeen',
                 'TileGStats','TileGClip','TileGSnaps','TileGApps','TileGAlerts','TileGActions',
                 'GStatsPrev','GClipPrev','GSnapsPrev','GAppsPrev','GAlertPrev','GActionsPrev',
                                  'ClipEmptyHint','ShotEmptyHint','BtnGear','PageReminders','RemindHost','BtnAddReminder',
                 'PageSettings','TileGRem','TileGSet','GRemPrev','GSetPrev',
                 'ST_hover','ST_full','ST_top','ST_auto','ST_accent','ST_scrub','ST_data','ST_reset',
                 'V_hover','V_full','V_top','V_auto','V_accent','V_opaque','V_scrub','V_data','V_reset',
                 'Sld_opaque','Sld_width','Sld_speed','Sld_retain','HomeScroll','HomeList','HomeGrid','HomeGridDock','HomeFade','ST_layout','V_layout',
                 'TileGFocus','GFocusPrev','PageFocus','FoArc','FoBig','FoState','FoStart','FoStartTxt','FoReset','Fo15','Fo25','Fo45','Fo60',
                 'A_taskmgr','A_capture','A_clippage','A_apppage','A_net','A_batt','A_restart','A_color')) {
    $script:ui[$n] = $window.FindName($n)
}

# ============================================================================
# PART 1 · settings, palettes, formatting, data collection
# ============================================================================

function Col([string]$h)  { ([System.Windows.Media.ColorConverter]::ConvertFromString($h)) }
function Brush([string]$h){ $b = New-Object System.Windows.Media.SolidColorBrush (Col $h); $b.Freeze(); $b }

function Format-Bytes([double]$b, [string]$suffix = '') {
    if     ($b -ge 1GB) { ('{0:N2} GB{1}'   -f ($b / 1GB),   $suffix) }
    elseif ($b -ge 1MB) { ('{0:N1} MB{1}'   -f ($b / 1MB),   $suffix) }
    elseif ($b -ge 1KB) { ('{0:N0} KB{1}'   -f ($b / 1KB),   $suffix) }
    else                { ('{0:N0} B{1}'    -f $b,           $suffix) }
}
function Get-LoadColor([double]$p) {
    if ($script:Settings -and [string]$script:Settings.Accent -eq 'mono') {
        if ($p -lt 55) { return '#C8CBD2' } elseif ($p -lt 82) { return '#EDEEF0' } else { return '#FFFFFF' }
    }
    if     ($p -lt 55) { '#3BDE8C' }
    elseif ($p -lt 82) { '#FFC53B' }
    else               { '#FF5A5A' }
}
function Set-Bar([System.Windows.Controls.Border]$bar, [double]$trackW, [double]$pct, [string]$hex) {
    if ($null -eq $bar) { return }
    $bar.Width = [Math]::Max(0, [Math]::Min($trackW, $trackW * $pct / 100))
    $bar.Background = (Brush $hex)
}
function Compact([string]$s) {
    $s = $s -replace 'Microsooft\w*\s*','' -replace 'Microsoft\s*',''
    $s = $s -replace '\(R\)|\(tm\)|\(C\)', '' -replace '\s{2,}', ' '
    $s = $s.Trim()
    if ($s.Length -gt 26) { $s.Substring(0, 25).Trim() + '···' } else { $s }
}

# ------------------------------------------------------------- settings ----
$script:Settings = [ordered]@{
    Topmost    = $true
    Opacity    = 0.96
    HoverOpen  = $true
    HomeLayout = 'list'
    Accent     = 'mono'
    ScrubShots = $true       # auto-purge screenshots after the retention window
    HideOnFS   = $false       # hide while a fullscreen window owns the screen
    Wide       = $false      # legacy (replaced by WidthScale)
    WidthScale = 1.0
    AnimMs     = 280
    Reminders  = @()
    RetainHrs  = 2           # screenshot / clipboard-image retention, hours
    FirstRun   = $true
    Launchers  = @()         # saved shortcut objects
}
function Get-DataDir {
    $d = Join-Path $env:LOCALAPPDATA 'Island'
    if (-not (Test-Path $d)) { $null = New-Item -ItemType Directory -Path $d }
    return $d
}
$Accents = @{
    'mono'   = @{ hi = '#FFFFFF'; lo = '#8A90A0' }
    'aurora' = @{ hi = '#3BDE8C'; lo = '#38E1FF' }
    'cyber'  = @{ hi = '#38E1FF'; lo = '#7C6CFF' }
    'flux'   = @{ hi = '#9D7CFF'; lo = '#FF7AC6' }
    'ember'  = @{ hi = '#FF6B4A'; lo = '#FFC53B' }
    'amber'  = @{ hi = '#FFC53B'; lo = '#FF9F43' }
    'reef'   = @{ hi = '#FF7AC6'; lo = '#3BDE8C' }
}
function Get-Accent { $acc = $Accents[$script:Settings.Accent]; if ($null -eq $acc) { $acc = $Accents['aurora'] }; $acc }

function Save-Settings {
    try { $script:Settings | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $script:ConfFile -Encoding UTF8 } catch { }
}
function Read-Settings {
    try {
        if (Test-Path $script:ConfFile) {
            $j = Get-Content -LiteralPath $script:ConfFile -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($k in @($script:Settings.Keys)) {
                $p = $j.PSObject.Properties[$k]; if ($p) { $script:Settings[$k] = $p.Value }
            }
        }
    } catch { }
}
Read-Settings

# ------------------------------------------------------------ constants ---
$script:PW = 254.0; $script:PH = 46.0     # pill   size
$script:EW = 430.0; $script:EH = 506.0    # island size
$script:TrackPill = 44.0; $script:TrackHero = 226.0
$script:Feed = New-Object System.Collections.Generic.List[string]

# --------------------------------------------------------- static info ----
$script:Static = @{
    CpuName = ''; Cores = 0; Threads = 0; GpuName = ''; TotalGB = 0.0; OsLine = ''; Boot = $null; HasBattery = $false
}
try {
    $cs  = Get-CimInstance Win32_Processor | Select-Object -First 1
    $script:Static.CpuName  = Compact([string]$cs.Name)
    $script:Static.Cores    = [int]$cs.NumberOfCores
    $script:Static.Threads  = [int]$cs.NumberOfLogicalProcessors
    $os  = Get-CimInstance Win32_OperatingSystem
    $script:Static.TotalGB  = $os.TotalVisibleMemorySize / 1MB
    $script:Static.Boot     = $os.LastBootUpTime
    try { $scr = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds; $script:Static.ResW = $scr.Width; $script:Static.ResH = $scr.Height } catch { $script:Static.ResW = 0; $script:Static.ResH = 0 }
    $cv  = Get-CimInstance Win32_VideoController | Select-Object -First 1
    $script:Static.GpuName  = Compact([string]$cv.Name)
    $null = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
    $script:Static.HasBattery = ($?)
    $nv = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -EA SilentlyContinue)
    $prod  = if ($nv.ProductName) { Compact([string]$nv.ProductName) } else { 'Windows' }
    $build = [int]$nv.CurrentBuildNumber
    if ($build -ge 22000) { $prod = $prod -replace 'Windows 10', 'Windows 11' }
    $rel = ''; if ($nv.DisplayVersion)   { $rel = "$($nv.DisplayVersion)" }
    elseif ($nv.ReleaseId) { $rel = "$($nv.ReleaseId)" }
    $script:Static.OsLine = ("{0} {1} · {2}" -f $prod, $rel, ('build ' + $build))
} catch { }
if (-not $script:Static.Cores)   { $script:Static.Cores = [Environment]::ProcessorCount }
if (-not $script:Static.Threads) { $script:Static.Threads = [Environment]::ProcessorCount }


# ----------------------------------------------------------- snapshots ----
$script:LastNetErrShown = $false
# ============================================================================
# BACKGROUND TELEMETRY ENGINE (v9)
# All slow queries run in their own runspace. Sources that fail once are
# disabled for the session (WMI perf adapter timeouts were stealing 1-2s/tick).
# UI thread only reads the last snapshot -> zero per-tick stalls.
# ============================================================================
$script:BgData = [hashtable]::Synchronized(@{ V = $null; Err = '' })
$script:BgScript = {
    param($slot)
    $ErrorActionPreference = 'SilentlyContinue'
    $Pc = @{}
    function Gpc([string]$cat, [string]$name, [string]$inst) {
        $key = $cat + '|' + $name + '|' + $inst
        if (-not $Pc.ContainsKey($key)) {
            $item = $null
            try {
                if ([string]::IsNullOrEmpty($inst)) { $item = New-Object System.Diagnostics.PerformanceCounter($cat, $name) }
                else { $item = New-Object System.Diagnostics.PerformanceCounter($cat, $name, $inst) }
                $null = $item.NextValue()
            } catch { $item = $null }
            $Pc[$key] = $item
        }
        $item = $Pc[$key]
        if ($item) { try { return [double]$item.NextValue() } catch { $Pc[$key] = $null; return $null } }
        return $null
    }
    $wmiPerf = $true; $acpi = $true; $acpiFail = 0; $tick = 0
    $temp = $null; $ip = ''; $ghz = 0
    $netCat = $null
    while ($true) {
        try {
            $s = @{}
            # -- cpu --
            $s.Cpu = $null
            if ($wmiPerf) {
                try { $o = Get-CimInstance Win32_PerfFormattedData_PerfOS_OperatingSystem -EA Stop; $s.Cpu = [double]$o.PercentProcessorTime }
                catch { $wmiPerf = $false }
            }
            if ($null -eq $s.Cpu -or $s.Cpu -le 0) { $v = Gpc 'Processor' '% Processor Time' '_Total'; if ($null -ne $v) { $s.Cpu = $v } }
            if ($null -eq $s.Cpu) { $s.Cpu = 0 }
            if ($s.Cpu -gt 100) { $s.Cpu = 100 }
            # -- memory (regular wmi, safe) --
            try {
                $os = Get-CimInstance Win32_OperatingSystem -EA Stop
                $tot = [double]$os.TotalVisibleMemorySize; $fr = [double]$os.FreePhysicalMemory
                $s.Mem = 100 * ($tot - $fr) / $tot; $s.MemGB = ($tot - $fr) / 1MB; $s.MemTotalGB = $tot / 1MB
                try { $s.Uptime = (Get-Date) - $os.LastBootUpTime } catch { $s.Uptime = [TimeSpan]::Zero }
            } catch { $s.Mem = 0; $s.MemGB = 0; $s.MemTotalGB = 0; $s.Uptime = [TimeSpan]::Zero }
            # -- net --
            $s.NetIn = 0; $s.NetOut = 0
            if ($wmiPerf) {
                try {
                    $ifs = @(Get-CimInstance Win32_PerfFormattedData_Tcpip_NetworkInterface -EA Stop | Where-Object { $_.Name -notmatch 'isatap|Loopback|Tun|Virtual|Hyper|vEthernet' })
                    $s.NetIn  = [double](($ifs | Measure-Object -Property BytesReceivedPersec -Sum).Sum)
                    $s.NetOut = [double](($ifs | Measure-Object -Property BytesSentPersec -Sum).Sum)
                } catch { $wmiPerf = $false }
            }
            if ($s.NetIn -eq 0 -and $s.NetOut -eq 0) {
                try {
                    if (-not $netCat) { $netCat = New-Object System.Diagnostics.PerformanceCounterCategory('Network Interface') }
                    foreach ($inst in $netCat.GetInstanceNames()) {
                        if ($inst -match 'isatap|loopback|Microsoft') { continue }
                        $a = Gpc 'Network Interface' 'Bytes Received/sec' $inst
                        $b = Gpc 'Network Interface' 'Bytes Sent/sec' $inst
                        if ($null -ne $a) { $s.NetIn += $a }
                        if ($null -ne $b) { $s.NetOut += $b }
                    }
                } catch { }
            }
            # -- disk activity --
            $s.DiskActive = 0; $s.DiskR = 0; $s.DiskW = 0
            if ($wmiPerf) {
                try { $pd = Get-CimInstance Win32_PerfFormattedData_PerfDisk_PhysicalDisk -Filter "Name='_Total'" -EA Stop; $s.DiskActive = 100 - [double]$pd.PercentIdleTime } catch { }
                try { $ld = Get-CimInstance Win32_PerfFormattedData_PerfDisk_LogicalDisk -Filter "Name='C:'" -EA Stop; $s.DiskR = [double]$ld.DiskReadBytesPersec; $s.DiskW = [double]$ld.DiskWriteBytesPersec } catch { }
            }
            if ($s.DiskActive -le 0) { $v = Gpc 'PhysicalDisk' '% Idle Time' '_Total'; if ($null -ne $v) { $s.DiskActive = 100 - $v } }
            if ($s.DiskR -le 0) { $v = Gpc 'PhysicalDisk' 'Disk Read Bytes/sec' '_Total'; if ($null -ne $v) { $s.DiskR = $v } }
            if ($s.DiskW -le 0) { $v = Gpc 'PhysicalDisk' 'Disk Write Bytes/sec' '_Total'; if ($null -ne $v) { $s.DiskW = $v } }
            # -- volume C: --
            try {
                $vol = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -EA Stop
                $s.DiskTotal = $vol.Size / 1GB; $s.DiskFree = $vol.FreeSpace / 1GB
                $s.DiskPct = if ($s.DiskTotal) { 100 * ($s.DiskTotal - $s.DiskFree) / $s.DiskTotal } else { 0 }
            } catch { $s.DiskTotal = 0; $s.DiskFree = 0; $s.DiskPct = 0 }
            # -- battery via kernel32 (instant) --
            try {
                $ps = [Island.Native]::Power()
                $s.AC = ($ps.ACLineStatus -eq 1)
                $s.NoBattery = (($ps.BatteryFlag -band 128) -ne 0)
                $s.Charging = (($ps.BatteryFlag -band 8) -ne 0)
                $s.BatPct = if ($ps.BatteryLifePercent -le 254) { [double]$ps.BatteryLifePercent } else { $null }
                $s.BatMin = if ($ps.BatteryLifeTime -gt 0 -and $ps.BatteryLifeTime -lt 71582788) { [int][Math]::Floor($ps.BatteryLifeTime / 60) } else { $null }
            } catch { $s.AC = $true; $s.NoBattery = $true; $s.Charging = $false; $s.BatPct = $null; $s.BatMin = $null }
            # -- temp: every 8th pass, self-disabling --
            $tick++
            if ($acpi -and ($tick % 8 -eq 1)) {
                try {
                    $z = Get-CimInstance -Namespace 'root/wmi' -ClassName MSAcpi_ThermalZoneTemperature -EA Stop | Sort-Object CurrentTemperature -Descending | Select-Object -First 1
                    if ($z) { $temp = [double]($z.CurrentTemperature / 10.0 - 273.15); $acpiFail = 0 }
                    else { $acpiFail++; if ($acpiFail -ge 2) { $acpi = $false } }
                } catch { $acpiFail++; if ($acpiFail -ge 2) { $acpi = $false } }
            }
            $s.Temp = $temp
            # -- one-time facts --
            if (-not $ip) { try { $a = [System.Net.Dns]::GetHostAddresses([System.Net.Dns]::GetHostName()) | Where-Object { $_.AddressFamily -eq 'InterNetwork' -and -not $_.ToString().StartsWith('127.') } | Select-Object -First 1; if ($a) { $ip = $a.ToString() } else { $ip = '127.0.0.1' } } catch { $ip = '' } }
            if ($ghz -eq 0) { try { $cp = Get-CimInstance Win32_Processor | Select-Object -First 1; if ($cp) { $ghz = $cp.MaxClockSpeed / 1000 } } catch { $ghz = -1 } }
            if ($ghz -lt 0) { $ghz = 0 }
            $s.IP = $ip; $s.Ghz = $ghz
            $slot.V = $s
        } catch { $slot.Err = $_.Exception.Message }
        Start-Sleep -Seconds 2
    }
}
$script:BgRunspace = [runspacefactory]::CreateRunspace()
$script:BgRunspace.ApartmentState = 'MTA'
$script:BgRunspace.ThreadOptions = 'ReuseThread'
try { $script:BgRunspace.Open() } catch { }
$script:BgPS = [PowerShell]::Create()
$script:BgPS.Runspace = $script:BgRunspace
$null = $script:BgPS.AddScript($script:BgScript).AddArgument($script:BgData).BeginInvoke()

# UI-side reader: shallow copy of the latest background snapshot
function Get-Snapshot {
    $d = $script:BgData.V
    if ($null -eq $d) {
        if ($script:LastSnap) { $d = $script:LastSnap } else {
            $d = @{ Cpu=0; Mem=0; MemGB=0; MemTotalGB=0; NetIn=0; NetOut=0; DiskActive=0; DiskR=0; DiskW=0
                    DiskTotal=0; DiskFree=0; DiskPct=0; AC=$true; NoBattery=$true; Charging=$false; BatPct=$null; BatMin=$null
                    Temp=$null; IP=''; Ghz=0; Uptime=([TimeSpan]::Zero) }
        }
    }
    $s = @{}
    foreach ($k in $d.Keys) { $s[$k] = $d[$k] }
    $s.ResW = $script:Static.ResW; $s.ResH = $script:Static.ResH
    $script:LastSnap = $s
    return $s
}

# ============================================================================
# PART 2 · state machine, animation, rendering
# ============================================================================

$script:State  = 'collapsed'
$script:HoldUntil = Get-Date
$script:Last = $null
$script:DataWarned = $false
$script:HstCpu = New-Object System.Collections.Generic.List[double]
$script:HstMem = New-Object System.Collections.Generic.List[double]
$script:HstIn = New-Object System.Collections.Generic.List[double]
$script:HstOut = New-Object System.Collections.Generic.List[double]
$script:TrackPill = 44.0
$script:TrackHero = 250.0

function Push-Val([System.Collections.Generic.List[double]]$list, [double]$v, [int]$cap = 70) {
    $list.Add($v)
    while ($list.Count -gt $cap) { $list.RemoveAt(0) }
}

# ---------------------------------------------------------- animation -----
function New-DA([double]$to, [int]$ms, [int]$delay = 0) {
    $a = New-Object System.Windows.Media.Animation.DoubleAnimation
    $a.To = $to
    $a.Duration = [TimeSpan]::FromMilliseconds($ms)
    $e = New-Object System.Windows.Media.Animation.CubicEase
    $e.EasingMode = [System.Windows.Media.Animation.EasingMode]::EaseOut
    $a.EasingFunction = $e
    if ($delay) { $a.BeginTime = [TimeSpan]::FromMilliseconds($delay) }
    return $a
}
function Anim-El($el, $dp, [double]$to, [int]$ms, [int]$delay = 0) {
    $el.BeginAnimation($dp, (New-DA $to $ms $delay))
}
function After([int]$ms, [scriptblock]$cb) {
    # The old version captured $t/$cb as function locals - gone by tick time
    # (the null-method dispatcher errors you saw). Attach everything to the
    # sender itself: tick handlers must never reference enclosing locals.
    $t = New-Object System.Windows.Threading.DispatcherTimer
    $t.Interval = [TimeSpan]::FromMilliseconds($ms)
    $t.Tag = $cb
    $t.Add_Tick({
        param($sender, $ev)
        $sender.Stop()
        $f = $sender.Tag
        if ($f) { try { & $f } catch { Log-Crash 'after' $_.Exception.Message } }
    })
    $t.Start()
}

function Invoke-State {
    param([string]$to, [bool]$force = $false, [switch]$sizeonly)
    if ($to -eq $script:State -and -not $force) { return }
    $script:State = $to
    $ui = $script:ui
    $acc = Get-Accent
    $expand = ($to -eq 'expanded')
    $tw = $script:PW; $th = $script:PH
    if ($expand) { $tw = $script:EW; $th = $script:EH }
    if ($sizeonly) {
        $ms = [int]$script:Settings.AnimMs
        if ($ms -le 0) { $ms = 260 }
        Anim-El $window ([System.Windows.FrameworkElement]::WidthProperty)  $tw $ms
        Anim-El $window ([System.Windows.FrameworkElement]::HeightProperty) $th $ms
        Anim-El $window ([System.Windows.Window]::LeftProperty) ($script:CX - $tw / 2) $ms
        $script:LastW = $tw; $script:LastH = $th; $script:LastL = $script:CX - $tw / 2
        if (-not $script:RelTimer) {
            $rt = New-Object System.Windows.Threading.DispatcherTimer
            $rt.Interval = [TimeSpan]::FromMilliseconds(680)
            $rt.Add_Tick({ param($snd) $snd.Stop()
                $window.Width = $script:LastW; $window.Height = $script:LastH; $window.Left = $script:LastL
                $window.BeginAnimation([System.Windows.FrameworkElement]::WidthProperty,  $null)
                $window.BeginAnimation([System.Windows.FrameworkElement]::HeightProperty, $null)
                $window.BeginAnimation([System.Windows.Window]::LeftProperty,             $null) })
            $script:RelTimer = $rt
        }
        $script:RelTimer.Stop(); $script:RelTimer.Start()
        return
    }

    $AnimMs = [int]$script:Settings.AnimMs
    if ($AnimMs -le 0) { $AnimMs = 280 }
    Anim-El $window ([System.Windows.FrameworkElement]::WidthProperty)  $tw $AnimMs
    Anim-El $window ([System.Windows.FrameworkElement]::HeightProperty) $th $AnimMs
    Anim-El $window ([System.Windows.Window]::LeftProperty) ($script:CX - $tw / 2) $AnimMs

    $script:LastW = $tw; $script:LastH = $th; $script:LastL = $script:CX - $tw / 2
    if (-not $script:RelTimer) {
        $rt = New-Object System.Windows.Threading.DispatcherTimer
        $rt.Interval = [TimeSpan]::FromMilliseconds(340)
        $rt.Add_Tick({ param($snd)
            $snd.Stop()
            $window.Width = $window.Width; $window.Height = $window.Height; $window.Left = $window.Left
            $window.BeginAnimation([System.Windows.FrameworkElement]::WidthProperty,  $null)
            $window.BeginAnimation([System.Windows.FrameworkElement]::HeightProperty, $null)
            $window.BeginAnimation([System.Windows.Window]::LeftProperty,             $null)
        })
        $script:RelTimer = $rt
    }
    $script:RelTimer.Stop(); $script:RelTimer.Start()
    if ($expand) {
        $ui = $script:ui
        $ui.Card.BorderBrush = (Brush ($acc.lo + '4D'))
        $ui.FullView.Visibility = 'Visible'
        Anim-El $ui.PillView ([System.Windows.UIElement]::OpacityProperty) 0 150
        Anim-El $ui.FullView ([System.Windows.UIElement]::OpacityProperty) 1 320 110
    } else {
        $ui.Card.BorderBrush = (Brush '#16FFFFFF')
        $ui.PillView.Visibility = 'Visible'
        $ui.PillView.Opacity = 1
        Anim-El $ui.FullView ([System.Windows.UIElement]::OpacityProperty) 0 170
        After 240 { $script:ui.FullView.Visibility = 'Collapsed' }
    }
}

# ------------------------------------------------------------- sparks -----
function Get-Points($data, [double]$max, [double]$w, [double]$h) {
    $n = $data.Count
    $pts = New-Object System.Collections.Generic.List[System.Windows.Point]
    if ($n -lt 2) { return $pts }
    $top = $h - 5; $span = $h - 12
    $neg = [Math]::Min(0, ($data | Measure-Object -Minimum).Minimum)
    if ($neg -lt 0) { $max = $max + (-$neg) }
    $step = $w / ($n - 1)
    for ($i = 0; $i -lt $n; $i++) {
        $y = $top - (([double]$data[$i] - $neg) / $max) * $span
        $y = [Math]::Max(2, [Math]::Min($h - 2, $y))
        $pts.Add((New-Object System.Windows.Point(($i * $step), $y)))
    }
    return $pts
}
function Get-SmoothD($pts, [double]$w, [double]$h, [bool]$close) {
    # Catmull-Rom -> cubic Bezier: the "apple" curve through sample points
    $n = $pts.Count
    if ($n -lt 2) { return '' }
    $sb = New-Object System.Text.StringBuilder
    $p0 = $pts[0]
    $null = $sb.Append(('M {0} {1}' -f [string][Math]::Round($p0.X,1), [string][Math]::Round($p0.Y,1)))
    for ($i = 0; $i -lt ($n - 1); $i++) {
        $a = $pts[[Math]::Max(0, ($i - 1))]; $b = $pts[$i]; $c = $pts[($i + 1)]; $d = $pts[[Math]::Min(($n - 1), ($i + 2))]
        $c1x = $b.X + (($c.X - $a.X) / 6.0); $c1y = $b.Y + (($c.Y - $a.Y) / 6.0)
        $c2x = $c.X - (($d.X - $b.X) / 6.0); $c2y = $c.Y - (($d.Y - $b.Y) / 6.0)
        $null = $sb.Append((' C {0} {1}, {2} {3}, {4} {5}' -f [Math]::Round($c1x,1), [Math]::Round($c1y,1),
                                                          [Math]::Round($c2x,1), [Math]::Round($c2y,1),
                                                          [Math]::Round($c.X,1),  [Math]::Round($c.Y,1)))
    }
    if ($close) {
        $null = $sb.Append((' L {0} {1} L 0 {1} Z' -f [Math]::Round($w,1), [Math]::Round($h,1)))
    }
    return $sb.ToString()
}

function Set-Spark {
    param($cv, $data, [string]$strokeHex, [string]$fillHex)
    if ($script:State -ne 'expanded') { return }
    $cv.Children.Clear()
    if ($data.Count -lt 2) { return }
    $w = $cv.ActualWidth; if ($w -lt 10) { $w = 250 }
    $h = $cv.ActualHeight
    $max = ($data | Measure-Object -Maximum).Maximum
    if ($max -lt 1) { $max = 1 }
    $pts = Get-Points $data $max $w $h
    $fp = New-Object System.Windows.Controls.Path
    $fp.Data = [System.Windows.Media.Geometry]::Parse((Get-SmoothD $pts $w $h $true))
    $fp.Fill = (Brush $fillHex)
    $cv.Children.Add($fp) | Out-Null
    $sp = New-Object System.Windows.Controls.Path
    $sp.Data = [System.Windows.Media.Geometry]::Parse((Get-SmoothD $pts $w $h $false))
    $sp.Stroke = (Brush $strokeHex)
    $sp.StrokeThickness = 1.5
    $sp.StrokeStartLineCap = 'Round'; $sp.StrokeEndLineCap = 'Round'
    $cv.Children.Add($sp) | Out-Null
}
function Set-NetSpark {
    if ($script:State -ne 'expanded') { return }
    $cv = $script:ui.NetSpark
    $cv.Children.Clear()
    $n = $script:HstIn.Count
    if ($n -lt 2 -or $script:HstOut.Count -ne $n) { return }
    $w = $cv.ActualWidth; if ($w -lt 10) { $w = 250 }
    $h = $cv.ActualHeight
    $max = [Math]::Max(
        ($script:HstIn  | Measure-Object -Maximum).Maximum,
        ($script:HstOut | Measure-Object -Maximum).Maximum)
    if ($max -lt 10KB) { $max = 10KB }
    $monoS = ($script:Settings.Accent -eq 'mono')
    if ($monoS) { $pal = @(@($script:HstIn, '#E6E8EB', '#14FFFFFF'), @($script:HstOut, '#6E737C', '#0DFFFFFF')) }
    else        { $pal = @(@($script:HstIn, '#38E1FF', '#1E38E1FF'), @($script:HstOut, '#FF7AC6', '#14FF7AC6')) }
    foreach ($pair in $pal) {
        $pts = Get-Points $pair[0] $max $w $h
        $fp = New-Object System.Windows.Controls.Path
        $fp.Data = [System.Windows.Media.Geometry]::Parse((Get-SmoothD $pts $w $h $true))
        $fp.Fill = (Brush $pair[2])
        $cv.Children.Add($fp) | Out-Null
        $sp = New-Object System.Windows.Controls.Path
        $sp.Data = [System.Windows.Media.Geometry]::Parse((Get-SmoothD $pts $w $h $false))
        $sp.Stroke = (Brush $pair[1]); $sp.StrokeThickness = 1.3
        $sp.StrokeStartLineCap = 'Round'; $sp.StrokeEndLineCap = 'Round'
        $cv.Children.Add($sp) | Out-Null
    }
}

# ---------------------------------------------------------- feed / toast --
$script:Feed = @()
function Show-Toast([string]$msg) {
    if ($script:Parked -eq $true) { UnPark-Island }
    $stamp = (Get-Date).ToString('HH:mm')
    $script:Feed = @("$stamp  $msg") + $script:Feed
    if ($script:Feed.Count -gt 8) { $script:Feed = $script:Feed[0..7] }
    $script:ui.FeedText.Text = $msg
    $script:HoldUntil = (Get-Date).AddSeconds(6)
    if ($script:State -ne 'expanded') { Invoke-State 'expanded' }
}
function Set-FeedDefault([object]$s) {
    if ((Get-Date) -lt $script:HoldUntil) { return }
    $txt = 'all systems nominal'
    if ($script:Feed.Count) { $txt = $script:Feed[0] }
    if ($script:Fo.Mode -eq 'run') { $mml = [Math]::Max(0, [int](($script:Fo.End - (Get-Date)).TotalSeconds)); $txt = 'FOCUS  ' + [int][Math]::Floor($mml / 60) + ':' + ($mml % 60).ToString('D2') + '  ·  ' + $txt }
    else {
        $txt = ('cpu {0:N0}%  ·  mem {1:N0}%  ·  net {2:N0} KB/s in' -f $s.Cpu, $s.Mem, ($s.NetIn / 1KB))
    }
    $script:ui.FeedText.Text = $txt
}

# ------------------------------------------------------------- render -----
function Push-History($s) {
    Push-Val $script:HstCpu $s.Cpu
    Push-Val $script:HstMem $s.Mem
    Push-Val $script:HstIn  ([double]$s.NetIn)
    Push-Val $script:HstOut ([double]$s.NetOut)
}
function Update-Clock {
    if ([bool]$script:Settings.HideOnFS) {
        try {
            if ([Island.Win]::CoveringPrimary()) {
                $script:FSCnt = [int]$script:FSCNT + 1
                $script:FSOff = 0
                if ($script:FSCnt -ge 4 -and $script:Parked -ne $true -and $script:State -eq 'collapsed' -and -not $script:ui.Card.IsMouseOver) {
                    Park-Island
                }
            } else {
                $script:FSCnt = 0
                $script:FSOff = [int]$script:FSOff + 1
                if ($script:Parked -eq $true -and $script:FSOff -ge 2) { UnPark-Island }
            }
        } catch { }
    } elseif ($script:Parked -eq $true) { UnPark-Island }
    # heartbeat every 60s: proves version + parked state + source health to boot log
    $script:HbCnt = [int]$script:HbCnt + 1
    if ($script:HbCnt -ge 60) {
        $script:HbCnt = 0
        try {
            $src = if ($script:BgData.V) { 'bg-ok' } else { 'bg-waiting' }
            ('{0}  alive   v{1} state={2} parked={3} fs={4} src={5}' -f (Get-Date -Format 'HH:mm:ss'), $script:Ver,
                $script:State, $script:Parked, $script:FSCnt, $src) | Add-Content -LiteralPath (Join-Path $env:TEMP 'IslandPS-boot.log') -Encoding UTF8
        } catch { }
    }
    if ($script:State -eq 'expanded' -and -not $script:PinOpen -and -not $script:ui.Card.IsMouseOver -and (Get-Date) -gt $script:HoldUntil) {
        Invoke-State 'collapsed'
    }
    $now = Get-Date
    $ui = $script:ui
    $ui.PillClock.Text = $now.ToString('HH:mm')
    $ui.BigClock.Text  = $now.ToString('HH:mm:ss')
    $ui.PillDate.Text  = $now.ToString('ddd d MMM')
    $ui.BigDate.Text   = $now.ToString('ddd, d MMM')
    $t = $now.TimeOfDay.TotalMilliseconds
    $r = [Math]::Sin((2 * $([Math]::PI) * $t) / 2400)
    if ($r -lt 0) { $r = 0 }
    $ui.PulseDot.Width = 9 + 6 * $r
    $ui.PulseDot.Height = 9 + 6 * $r
    $ui.PulseDot.Opacity = 0.35 + 0.65 * $r
    if ($script:Last -and $script:State -eq 'collapsed') { Push-History $script:Last }
    Fo-Tick
    Check-Reminders $now
    $script:ClkN = ([int]$script:ClkN + 1)
    if ($script:ClkN -ge 60) { $script:ClkN = 0; Prune-ClipboardImages }
}
$script:WarnedLow = $false
function Format-Rate([double]$b) {
    if     ($b -ge 1GB) { ,@(('{0:N2}' -f ($b / 1GB)), 'GB/s') }
    elseif ($b -ge 1MB) { ,@(('{0:N1}' -f ($b / 1MB)), 'MB/s') }
    elseif ($b -ge 1KB) { ,@(('{0:N0}' -f ($b / 1KB)), 'KB/s') }
    else                { ,@(('{0:N0}' -f $b), 'B/s') }
}
function Update-UI($s) {
    $script:Last = $s
    $ui = $script:ui

    # ---- pill ----
    $ui.CpuPillVal.Text = ('{0:N0}%' -f $s.Cpu)
    $ui.RamPillVal.Text = ('{0:N0}%' -f $s.Mem)
    $d = Format-Rate $s.NetIn
    $u = Format-Rate $s.NetOut
    $ui.NetDownPill.Text = ($d[0] + ' ' + $d[1])
    $ui.NetUpPill.Text   = ($u[0] + ' ' + $u[1])
    Set-Bar $ui.CpuPillBar $script:TrackPill $s.Cpu (Get-LoadColor $s.Cpu)
    Set-Bar $ui.RamPillBar $script:TrackPill ([Math]::Max(0, $s.Mem)) (Get-LoadColor ([Math]::Max(0, $s.Mem)))

    # ---- hero cards ----
    $ui.HeroCpuVal.Text = ('{0:N0}' -f $s.Cpu)
    $ui.HeroCpuName.Text = $script:Static.CpuName
    $ui.HeroCpuCores.Text = ('{0}C / {1}T @ {2:N1} GHz' -f $script:Static.Cores, $script:Static.Threads, $s.Ghz)
    Set-Bar $ui.HeroCpuBar $script:TrackHero $s.Cpu (Get-LoadColor $s.Cpu)

    $ui.HeroMemVal.Text = ('{0:N0}' -f $s.Mem)
    $ui.HeroMemGb.Text = ('{0:N1} / {1:N0} GB' -f $s.MemGB, $s.MemTotalGB)
    $ui.HeroMemSub.Text = 'used'
    Set-Bar $ui.HeroMemBar $script:TrackHero ([Math]::Max(0, $s.Mem)) (Get-LoadColor ([Math]::Max(0, $s.Mem)))

    $ui.NetDownBig.Text = $d[0]
    $ui.NetDownUnit.Text = $d[1]
    $ui.NetUpBig.Text = $u[0]
    $mono = ($script:Settings.Accent -eq 'mono')
    $ui.NetDownBig.Foreground = (Brush $(if ($mono) { '#F3F4F6' } else { '#38E1FF' }))
    $ui.NetUpBig.Foreground  = (Brush $(if ($mono) { '#959BA5' } else { '#FF7AC6' }))
    $ui.TxtLink.Text = 'ethernet · ' + $s.IP

    $ui.StoVal.Text = ('{0:N0}' -f $s.DiskPct)
    Set-Bar $ui.StoBar $script:TrackHero $s.DiskPct (Get-LoadColor $s.DiskPct)
    $ui.StoFree.Text = ('{0:N0} GB free of {1:N0} GB (C:)' -f $s.DiskFree, $s.DiskTotal)
    $rd = Format-Rate $s.DiskR
    $rw = Format-Rate $s.DiskW
    $ui.StoAct.Text = ('read ' + $rd[0] + ' ' + $rd[1] + '  ·  write ' + $rw[0] + ' ' + $rw[1])

    # ---- mini strip ----
    $ts = $s.Uptime
    $ui.UpVal.Text = if ($ts.Days -ge 1) { ('{0}d {1}h' -f $ts.Days, $ts.Hours) }
                    elseif ($ts.Hours -ge 1) { ('{0}h {1}m' -f $ts.Hours, $ts.Minutes) }
                    else { ('{0}m' -f $ts.Minutes) }
    $ui.UpSub.Text = if ($script:Static.Boot) { 'boot ' + $script:Static.Boot.ToString('dd MMM HH:mm') } else { '' }
    $ui.TxtIp.Text = $s.IP
    $ui.TxtOs.Text = $script:Static.OsLine
    $ui.TxtHost.Text = $env:COMPUTERNAME
    $ui.GpuVal.Text = $script:Static.GpuName
    $ui.ResVal.Text = ('{0} x {1}' -f $s.ResW, $s.ResH)

    if ($null -ne $s.Temp) {
        $ui.TempChip.Visibility = 'Visible'
        $ui.TempText.Text = ('{0:N0}' -f $s.Temp) + [string][char]0x00B0 + 'C'
    } else {
        $ui.TempChip.Visibility = 'Collapsed'
    }

    if ($s.NoBattery) {
        $ui.PodBattery.Visibility = 'Collapsed'
        $ui.PwrVal.Text = 'AC'
        $ui.PwrSub.Text = 'mains powered'
    } else {
        if ($script:PW -lt 296) {
            $script:PW = 296.0
            if ($script:State -eq 'collapsed') { Invoke-State 'collapsed' -force $true -sizeonly $true }
        }
        $ui.PodBattery.Visibility = 'Visible'
        $ui.BatteryPillVal.Text = ('{0:N0}%' -f $s.BatPct)
        if ($s.Charging) {
            $ui.BatteryPillState.Text = [string][char]0x26A1
            $ui.BatteryPillState.Foreground = (Brush $(if ($script:Settings.Accent -eq 'mono') {'#EAECEF'} else {'#3BDE8C'}))
        } else {
            $ui.BatteryPillState.Text = [string][char]0x25CF
            $ui.BatteryPillState.Foreground = (Brush ($(if ($script:Settings.Accent -eq 'mono') { if ($s.AC) {'#6E737C'} else {'#EAECEF'} } elseif ($s.AC) {'#8A90A0'} else {'#FFC53B'})))
        }
        $ui.PwrVal.Text = ('{0:N0}%' -f $s.BatPct)
        $ui.PwrSub.Text = if ($s.Charging) { 'charging' } elseif ($s.AC) { 'plugged in' } else { 'on battery' }
        if ($null -ne $s.BatMin -and $s.BatMin -gt 0 -and $s.BatMin -lt 3600) {
            $bh = [int][Math]::Floor($s.BatMin / 60); $bm = $s.BatMin % 60
            $ui.PwrSub.Text = $ui.PwrSub.Text + ('  ' + $(if ($bh -gt 0) { $bh.ToString() + 'h' + ('{0:D2}' -f $bm) } else { $bm.ToString() + 'm' }))
        }
        if ((-not $s.AC) -and $s.BatPct -le 20 -and -not $script:WarnedLow) {
            $script:WarnedLow = $true
            Show-Toast ('battery low · ' + ('{0:N0}' -f $s.BatPct) + '% — plug in soon')
        }
        if ($s.AC -or $s.BatPct -gt 40) { $script:WarnedLow = $false }
    }

    # ---- pulse colours + sparklines ----
    if     ($s.Cpu -gt 82) { $script:ui.PulseDot.Fill = (Brush '#FF5A5A') }
    elseif ($s.Cpu -gt 55) { $script:ui.PulseDot.Fill = (Brush '#FFC53B') }
    else                   { $script:ui.PulseDot.Fill = (Brush '#3BDE8C') }
    Push-History $s
    $cpuCol = ($(if ($s.Cpu -gt 0) { (Get-LoadColor $s.Cpu) } elseif ($s.Mem -gt 0) { (Get-LoadColor $s.Mem) } else { '#8A90A0' }))
    # group previews (cheap text writes; keep home alive)
    $gp = $ui.GStatsPrev
    if ($gp) { $np = Format-Rate $s.NetIn; $gp.Text = ('cpu {0:N0}%  mem {1:N0}  net {2} {3}' -f $s.Cpu, $s.Mem, $np[0], $np[1]) }
    $gc = $ui.GClipPrev
    if ($gc) { $top = @($script:Clip) | Select-Object -First 1; if ($top) { $t2 = ($top.Text -replace '\s+',' '); $gc.Text = if ($t2.Length -gt 22) { $t2.Substring(0,21)+'…' } else { $t2 } } else { $gc.Text = 'nothing yet' } }
    $gs = $ui.GSnapsPrev; if ($gs) { $n = @($script:ShotSig -split ';' | Where-Object { $_ }).Count; $gs.Text = if ($n) { "$n recent captures" } else { 'empty for 2h' } }
    $ga = $ui.GAppsPrev; if ($ga) { $na = @($script:Settings.Launchers).Count; $ga.Text = if ($na) { "$na pinned" } else { 'drop a .lnk here' } }
    $gr = $ui.GAlertPrev; if ($gr) { $gr.Text = if ($script:Alerts.Count) { $script:Alerts[0] } else { 'all clear' } }
    $gact = $ui.GActionsPrev; if ($gact) { $gact.Text = 'capture · task mgr · accent' }
    Set-Spark $ui.CpuSpark $script:HstCpu $cpuCol '#0CFFFFFF'
    Set-Spark $ui.MemSpark $script:HstMem (Get-LoadColor $([Math]::Max(0, $s.Mem))) '#0CFFFFFF'
    Set-NetSpark
    Set-FeedDefault $s
    if (-not $script:DataWarned -and $s.Cpu -le 0 -and $s.Mem -le 0) {
        $script:DataWarned = $true
        Add-Feed 'telemetry blocked - counters unavailable (service/policy)'
    }
    if (($s.Cpu -gt 0) -or ($s.Mem -gt 0)) { $script:DataWarned = $false }
}

# ============================================================================
# PART 2.5 · launchers, screenshots, clipboard shelf, hardware alerts
# ============================================================================

Add-Type -AssemblyName Microsoft.VisualBasic

function Add-Feed([string]$msg) {
    $script:Feed = @((Get-Date).ToString('HH:mm') + '  ' + $msg) + @($script:Feed)
    if ($script:Feed.Count -gt 8) { $script:Feed = @($script:Feed[0..7]) }
}

$script:DataDir   = Join-Path $env:LOCALAPPDATA 'Island'
$script:LaunchDir = Join-Path $script:DataDir 'launchers'
$script:ClipDir   = Join-Path $script:DataDir 'clipboard'
foreach ($d in @($script:DataDir, $script:LaunchDir, $script:ClipDir)) {
    if (-not (Test-Path -LiteralPath $d)) { try { $null = New-Item -ItemType Directory -Path $d -Force } catch { } }
}

# ------------------------------------------------------------- shortcuts ---
function Get-ShortcutTarget([string]$path) {
    try {
        $ws = New-Object -ComObject WScript.Shell
        $sc = $ws.CreateShortcut($path)
        $tgt = [string]$sc.TargetPath
        [void][Runtime.InteropServices.Marshal]::ReleaseComObject($ws)
        if ($tgt) { return $tgt }
    } catch { }
    if ($path.ToLower().EndsWith('.url')) {
        foreach ($line in @(Get-Content -LiteralPath $path -EA SilentlyContinue)) {
            if ($line -match '^\s*URL=(.+)$') { return $Matches[1].Trim() }
        }
    }
    return ''
}
function Invoke-Launch([string]$path) {
    try {
        $ext = [System.IO.Path]::GetExtension($path).ToLower()
        if ($ext -in @('.lnk', '.url')) {
            $t = Get-ShortcutTarget $path
            if ($t -match '^https?://') { $null = [System.Diagnostics.Process]::Start($t); return }
            if ($t -and (Test-Path -LiteralPath $t -EA SilentlyContinue)) { $null = [System.Diagnostics.Process]::Start($t); return }
        }
        $null = [System.Diagnostics.Process]::Start($path)
    } catch {
        try { $null = & explorer.exe $path } catch { Log-Crash 'launch' $_.Exception.Message }
    }
}
function Add-Launcher([string]$srcpath) {
    try {
        $ext = [System.IO.Path]::GetExtension($srcpath).ToLower()
        if ($ext -notin @('.lnk', '.url', '.exe')) { Show-Toast 'the island takes .lnk / .url / .exe shortcuts'; return }
        $store = $srcpath
        if ($ext -ne '.exe' -and -not $srcpath.StartsWith($script:LaunchDir)) {
            $store = Join-Path $script:LaunchDir ([System.IO.Path]::GetFileName($srcpath))
            Copy-Item -LiteralPath $srcpath -Destination $store -Force -EA SilentlyContinue
        }
        if (-not (Test-Path -LiteralPath $store -EA SilentlyContinue)) { Show-Toast 'could not pin (file unreadable)'; return }
        $name = [System.IO.Path]::GetFileNameWithoutExtension($srcpath)
        if ($name.Length -gt 16) { $name = $name.Substring(0, 15) }
        foreach ($x in @($script:Settings.Launchers)) { if ([string]$x.Path -eq $store) { Show-Toast ('already on the island: ' + $name); return } }
        $list = @($script:Settings.Launchers)
        $list += , [pscustomobject]@{ Path = $store; Name = $name }
        $script:Settings.Launchers = $list
        Save-Settings; Update-Launchers
        Show-Toast ('pinned · ' + $name)
    } catch { Log-Crash 'launcher-add' $_.Exception.Message }
}
function Remove-Launcher([string]$path) {
    try {
        $script:Settings.Launchers = @($script:Settings.Launchers | Where-Object { [string]$_.Path -ne $path })
        if ($path.StartsWith($script:LaunchDir)) { Remove-Item -LiteralPath $path -Force -EA SilentlyContinue }
        Save-Settings; Update-Launchers
    } catch { Log-Crash 'launcher-remove' $_.Exception.Message }
}
function New-ImageEl([string]$source, [int]$px, [double]$w, [double]$h, [string]$stretch) {
    $img = New-Object System.Windows.Controls.Image
    try {
        $fs = [System.IO.File]::Open($source, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $bi = New-Object System.Windows.Media.Imaging.BitmapImage
        $bi.BeginInit(); $bi.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
        $bi.DecodePixelWidth = $px; $bi.StreamSource = $fs
        $bi.EndInit(); $bi.Freeze(); $fs.Dispose()
        $img.Source = $bi
    } catch { }
    $img.Width = $w; $img.Height = $h; $img.Stretch = $stretch
    return $img
}
$script:IconCache = @{}
function New-FileIconEl([string]$path) {
    try {
        $cached = $script:IconCache[$path]
        if ($cached) {
            $img2 = New-Object System.Windows.Controls.Image
            $img2.Source = $cached; $img2.Width = 26; $img2.Height = 26; $img2.Stretch = 'Uniform'
            return $img2
        }
        $p = $path
        if ($p.ToLower().EndsWith('.lnk') -or $p.ToLower().EndsWith('.url')) {
            $t = Get-ShortcutTarget $p
            if ($t -and $t -notmatch '^https?://' -and (Test-Path -LiteralPath $t -EA SilentlyContinue)) { $p = $t }
        }
        $ico = [System.Drawing.Icon]::ExtractAssociatedIcon($p)
        $bmp = $ico.ToBitmap()
        $ms = New-Object System.IO.MemoryStream
        $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
        $bmp.Dispose(); $ico.Dispose(); $ms.Position = 0
        $bi = New-Object System.Windows.Media.Imaging.BitmapImage
        $bi.BeginInit(); $bi.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
        $bi.StreamSource = $ms; $bi.EndInit(); $bi.Freeze()
        $img = New-Object System.Windows.Controls.Image
        $img.Source = $bi; $img.Width = 26; $img.Height = 26; $img.Stretch = 'Uniform'
        $script:IconCache[$path] = $bi
        return $img
    } catch {
        $tb = New-Object System.Windows.Controls.TextBlock
        $tb.Text = '?'
        try { $fn = [System.IO.Path]::GetFileNameWithoutExtension($path); if ($fn) { $tb.Text = [string]$fn[0] } } catch { }
        $tb.FontSize = 15; $tb.Foreground = (Brush '#9AA3B6')
        $tb.HorizontalAlignment = 'Center'; $tb.Margin = (New-Object System.Windows.Thickness 0,3,0,0)
        return $tb
    }
}
# generic clickable tile: behaviour travels in the Tag hashtable (no closures)
function New-Tile([double]$w, [double]$h, $visual, [string]$tip, [hashtable]$meta, $ctxItems) {
    $b = New-Object System.Windows.Controls.Border
    $b.Width = $w; $b.Height = $h; $b.CornerRadius = 9
    $b.Background = (Brush '#16FFFFFF'); $b.Margin = (New-Object System.Windows.Thickness 0,0,5,0)
    $b.Cursor = 'Hand'; $b.Tag = $meta
    if ($tip) { $b.ToolTip = $tip }
    if ($visual) { $b.Child = $visual }
    if ($ctxItems) {
        $cm = New-Object System.Windows.Controls.ContextMenu
        foreach ($ci in $ctxItems) {
            $mi = New-Object System.Windows.Controls.MenuItem
            $mi.Header = [string]$ci.Text
            $mi.Tag = $ci
            $mi.Add_Click({ Island-TileAction $sender.Tag.Action $sender.Tag })
            $null = $cm.Items.Add($mi)
        }
        $b.ContextMenu = $cm
    }
    return $b
}
# central dispatcher for every tile / menu action on the shelves
function Island-TileAction([string]$kind, [hashtable]$t) {
    try {
        switch ($kind) {
            'launch'      { Invoke-Launch ([string]$t.Path) }
            'unpin'       { Remove-Launcher ([string]$t.Path) }
            'openfile'    { try { $null = [System.Diagnostics.Process]::Start([string]$t.Path) } catch { try { $null = & explorer.exe ([string]$t.Path) } catch { } } }
            'openas'      { try { $null = & rundll32.exe shell32.dll,OpenAs_RunDLL ([string]$t.Path) } catch { } }
            'copyimg'     { $u = New-Object System.Uri([string]$t.Path, [System.UriKind]::Absolute); $bi = New-Object System.Windows.Media.Imaging.BitmapImage($u); $bi.Freeze(); [System.Windows.Clipboard]::SetImage($bi) }
            'recycle'     { Recycle-File ([string]$t.Path); Update-Screenshots }
            'keep'        { $script:IgnoredShots = @($script:IgnoredShots) + @([string]$t.Path); Update-Screenshots }
            'clippaste'   { Put-Back $t.Item; After 250 { try { [System.Windows.Forms.SendKeys]::SendWait('^v') } catch { } } }
            'clipcopy'    { Put-Back $t.Item; Show-Toast 'restored · ctrl+V anywhere' }
            'clipremove'  { Remove-ClipItem $t.Item }
        }
    } catch { Log-Crash 'tile-action' ($_.Exception.Message + ' ' + $kind) }
}
function Wire-Tile($b) {
    $b.Add_PreviewMouseLeftButtonUp({
        param($snd, $e)
        $e.Handled = $true
        $m = $snd.Tag
        if ($m -and $m.Click)  { Island-TileAction ([string]$m.Click)  $m }
    })
    $b.Add_MouseDown({
        param($snd, $e)
        if ($e.ClickCount -eq 2) {
            $m = $snd.Tag
            if ($m -and $m.Dbl)  { Island-TileAction ([string]$m.Dbl) $m }
        }
    })
}

function Update-Launchers {
    try {
        $h = $script:ui.LaunchHost
        $h.Children.Clear()
        foreach ($x in @($script:Settings.Launchers)) {
            $path = [string]$x.Path; $name = [string]$x.Name
            if (-not (Test-Path -LiteralPath $path -EA SilentlyContinue)) { continue }
            $sp = New-Object System.Windows.Controls.StackPanel
            $sp.HorizontalAlignment = 'Center'
            $sp.Children.Add((New-FileIconEl $path)) | Out-Null
            $lbl = New-Object System.Windows.Controls.TextBlock
            $lbl.Text = $name.Substring(0, [Math]::Min(6, $name.Length))
            $lbl.FontSize = 7.5; $lbl.Foreground = (Brush '#77FFFFFF')
            $lbl.HorizontalAlignment = 'Center'; $lbl.TextAlignment = 'Center'
            $sp.Children.Add($lbl) | Out-Null
            $tile = New-Tile 44 52 $sp $name @{ Click = 'launch'; Path = $path } @(
                @{ Text = 'unpin from island'; Action = 'unpin'; Path = $path }
            )
            Wire-Tile $tile
            $h.Children.Add($tile) | Out-Null
        }
        if ($h.Children.Count -eq 0) {
            $tb = New-Object System.Windows.Controls.TextBlock
            $tb.Text = 'drop a shortcut here'
            $tb.FontSize = 9; $tb.Foreground = (Brush '#5E6678'); $tb.TextWrapping = 'Wrap'; $tb.Width = 66
            $tb.Margin = (New-Object System.Windows.Thickness 0,10,0,0)
            $h.Children.Add($tb) | Out-Null
        }
    } catch { Log-Crash 'launchers' $_.Exception.Message }
}
function Browse-Launchers {
    try {
        $of = New-Object Microsoft.Win32.OpenFileDialog
        $of.Title = 'Pin shortcuts to the island'
        $of.Multiselect = $true
        $of.Filter = 'Shortcuts (*.lnk;*.url;*.exe)|*.lnk;*.url;*.exe|All files (*.*)|*.*'
        try { $of.InitialDirectory = [Environment]::GetFolderPath('Desktop') } catch { }
        if ($of.ShowDialog($window) -eq $true) { foreach ($f in $of.FileNames) { Add-Launcher $f } }
    } catch { Log-Crash 'browse' $_.Exception.Message }
}

# ------------------------------------------------- screenshots (2-hour) ----
$script:IgnoredShots = @()
$script:ShotSig = ''
$script:LastPurge = (Get-Date).AddMinutes(-99)
$script:ShotDirs = @(
    (Join-Path $env:USERPROFILE 'OneDrive\Pictures\Screenshots'),
    (Join-Path $env:USERPROFILE 'Pictures\Screenshots'),
    (Join-Path $env:LOCALAPPDATA 'Packages\Microsoft.ScreenSketch_8wekyb3d8bbwe\TempState')
) | Where-Object { Test-Path -LiteralPath $_ -EA SilentlyContinue }
function Take-Screenshot {
    try {
        # blink-out: the island must never be in its own capture.
        # park it, force one full render pass so that frame is what shows on screen, then grab.
        $wasParked = ($script:Parked -eq $true)
        if (-not $wasParked) {
            $window.BeginAnimation([System.Windows.Window]::TopProperty, $null)
            $window.Top = -9999
        }
        $window.Dispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Render) | Out-Null
        Start-Sleep -Milliseconds 70
        $b = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
        $bmp = New-Object System.Drawing.Bitmap($b.Width, $b.Height)
        $g = [System.Drawing.Graphics]::FromImage($bmp)
        $g.CopyFromScreen(0, 0, 0, 0, $bmp.Size)
        $dir = Join-Path $env:USERPROFILE 'Pictures\Screenshots'
        if (-not (Test-Path -LiteralPath $dir)) { try { New-Item -ItemType Directory -Path $dir -Force | Out-Null } catch { } }
        $fp = Join-Path $dir ('Island_' + (Get-Date).ToString('yyyyMMdd_HHmmss') + '.png')
        $bmp.Save($fp, [System.Drawing.Imaging.ImageFormat]::Png)
        $g.Dispose()
        try { [System.Windows.Forms.Clipboard]::SetImage($bmp) } catch { }
        $bmp.Dispose()
        if (-not $wasParked) { $window.Top = $script:CY }
        $script:ShotSig = ''
        Update-Screenshots
        Show-Toast 'screen captured · SNAPS + clipboard · yours for 2 hours'
    } catch {
        try { $window.Top = $script:CY } catch { }
        Log-Crash 'snap-btn' $_.Exception.Message
    }
}

function Recycle-File([string]$path) {
    try { [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($path, 'OnlyErrorDialogs', 'SendToRecycleBin') }
    catch { try { Remove-Item -LiteralPath $path -Force -EA Stop } catch { } }
}
function Update-Screenshots {
    if ($script:State -ne 'expanded') { $script:ShotDirty = $true; return }
    try {
        $script:ShotDirty = $false
        $h = $script:ui.ShotHost
        $cut = (Get-Date).AddHours(-[double]$script:Settings.RetainHrs)
        $files = @()
        foreach ($d in $script:ShotDirs) {
            try {
                $files += @(Get-ChildItem -LiteralPath $d -File -EA SilentlyContinue |
                    Where-Object { $_.Extension -in @('.png', '.jpg', '.jpeg') -and $_.LastWriteTime -gt $cut -and $script:IgnoredShots -notcontains $_.FullName })
            } catch { }
        }
        $files = @($files | Sort-Object LastWriteTime -Descending | Select-Object -First 5)
        $sig = ($files | ForEach-Object { $_.FullName + $_.LastWriteTime.Ticks }) -join ';'
        if ($sig -ne $script:ShotSig) {
            $script:ShotSig = $sig
            try { $h.Children.Clear() } catch { }
            foreach ($f in $files) {
                $p = $f.FullName
                $img = New-ImageEl $p 160 58 40 'UniformToFill'
                $tile = New-Tile 60 44 $img ($f.Name + ' · ' + $f.LastWriteTime.ToString('HH:mm')) @{ Click = 'openfile'; Dbl = 'openfile'; Path = $p } @(
                    @{ Text = 'open with…';  Action = 'openas';   Path = $p }
                    @{ Text = 'copy image';  Action = 'copyimg';  Path = $p }
                    @{ Text = 'recycle now'; Action = 'recycle';  Path = $p }
                    @{ Text = 'keep this one (stop watching)'; Action = 'keep'; Path = $p }
                )
                Wire-Tile $tile
                $h.Children.Add($tile) | Out-Null
            }
            Set-EmptyHint 'ShotEmptyHint' ($h.Children.Count -eq 0)
            $n = @($files).Count
            $el = $script:ui.ShotCount
            if ($el) { $el.Text = ($n.ToString() + (' · 2h' )) }
        }
        # auto-recycle anything past the retention line, 10-minute cadence
        if ($script:Settings.ScrubShots -and (Get-Date) -gt $script:LastPurge.AddMinutes(10)) {
            $script:LastPurge = Get-Date
            $rm = 0
            foreach ($d in $script:ShotDirs) {
                try {
                    Get-ChildItem -LiteralPath $d -File -EA SilentlyContinue |
                        Where-Object { $_.Extension -in @('.png', '.jpg', '.jpeg') -and $_.LastWriteTime -lt $cut -and $script:IgnoredShots -notcontains $_.FullName } |
                        ForEach-Object { try { Recycle-File $_.FullName; $rm++ } catch { } }
                } catch { }
            }
            if ($rm -gt 0) { Add-Feed ('recycled ' + $rm + ' old screenshot' + $(if ($rm -gt 1) { 's' } else { '' })) }
        }
    } catch { Log-Crash 'screenshots' $_.Exception.Message }
}

# ---------------------------------------------------- clipboard shelf ------
$script:Clip = @()
$script:ClipSig = ''
function Put-Back($c) {
    try {
        if ($c.Kind -eq 'image') {
            $u  = New-Object System.Uri([string]$c.Path, [System.UriKind]::Absolute)
            $bi = New-Object System.Windows.Media.Imaging.BitmapImage($u)
            $bi.Freeze()
            [System.Windows.Clipboard]::SetImage($bi)
        } else {
            [System.Windows.Clipboard]::SetText([string]$c.Text)
        }
    } catch { }
}
function Remove-ClipItem($c) {
    $script:Clip = @($script:Clip | Where-Object { -not ($_.Kind -eq $c.Kind -and $_.Time -eq $c.Time -and $_.Text -eq $c.Text) })
    if ($c.Kind -eq 'image' -and $c.Path) { try { Remove-Item -LiteralPath $c.Path -Force -EA SilentlyContinue } catch { } }
    Update-ClipboardShelf
}
function Grab-ClipboardNow {
    try {
        $entry = $null
        if ([System.Windows.Clipboard]::ContainsFileDropList()) {
            $lst = [System.Windows.Clipboard]::GetFileDropList()
            if ($lst.Count -gt 0) {
                $j = ($lst | ForEach-Object { [string]$_ }) -join "`n"
                $entry = [pscustomobject]@{ Kind = 'files'; Text = $j; Path = [string]$lst[0]; Time = (Get-Date) }
            }
        }
        if (-not $entry -and [System.Windows.Clipboard]::ContainsImage()) {
            $src = $null
            try { $src = [System.Windows.Clipboard]::GetImage() } catch { }
            if ($src) {
                $fp = Join-Path $script:ClipDir ('clip_' + (Get-Date).ToString('yyyyMMdd_HHmmss_fff') + '.png')
                try {
                    $enc = New-Object System.Windows.Media.Imaging.PngBitmapEncoder
                    $enc.Frames.Add([System.Windows.Media.Imaging.BitmapFrame]::Create($src))
                    $fs = [System.IO.File]::Create($fp); $enc.Save($fs); $fs.Close()
                    $entry = [pscustomobject]@{ Kind = 'image'; Text = ('image · ' + $src.PixelWidth + 'x' + $src.PixelHeight); Path = $fp; Time = (Get-Date) }
                } catch { }
            }
        }
        if (-not $entry -and [System.Windows.Clipboard]::ContainsText()) {
            $t = [System.Windows.Clipboard]::GetText()
            if ($t -and $t.Trim().Length -gt 0) {
                $entry = [pscustomobject]@{ Kind = 'text'; Text = $t; Path = ''; Time = (Get-Date) }
            }
        }
        if (-not $entry) { return }
        $sig = $entry.Kind + '|' + $entry.Path + '|' + $entry.Text.Substring(0, [Math]::Min(200, $entry.Text.Length))
        if ($sig -eq $script:ClipSig) { return }
        $script:ClipSig = $sig
        $script:Clip = @($script:Clip | Where-Object { ($_.Kind + '|' + $_.Path + '|' + $_.Text) -ne $sig })
        $script:Clip = @($entry) + @($script:Clip)
        while ($script:Clip.Count -gt 12) {
            $drop = $script:Clip[$script:Clip.Count - 1]
            $script:Clip = @($script:Clip[0..($script:Clip.Count - 2)])
            if ($drop.Kind -eq 'image' -and $drop.Path) { try { Remove-Item -LiteralPath $drop.Path -Force -EA SilentlyContinue } catch { } }
        }
        Update-ClipboardShelf
    } catch { }
}
function Set-EmptyHint([string]$name, [bool]$show) {
    $el = $script:ui[$name]
    if ($el) { $el.Visibility = $(if ($show) { 'Visible' } else { 'Collapsed' }) }
}

function Update-ClipboardShelf {
    # never rebuild the wall of tiles while the island is just a pill - defer till it is seen
    if ($script:State -ne 'expanded') { $script:ClipDirty = $true; return }
    try {
        $script:ClipDirty = $false
$script:ShotDirty = $false

# housekeeping: move expired snaps/screenshots to Recycle Bin (10-min cadence).
# runs from ShotTimer regardless of open/closed so cleanup never blocks on UI.
function Update-SnapRetentionPurge {
    try {
        if (-not [bool]$script:Settings.ScrubShots) { return }
        if ((Get-Date) -lt $script:LastPurge.AddMinutes(10)) { return }
        $script:LastPurge = Get-Date
        $cut = (Get-Date).AddHours(-[double]$script:Settings.RetainHrs)
        $rm = 0
        foreach ($d in $script:ShotDirs) {
            try {
                Get-ChildItem -LiteralPath $d -File -EA SilentlyContinue |
                    Where-Object { $_.Extension -in @('.png', '.jpg', '.jpeg') -and $_.LastWriteTime -lt $cut -and $script:IgnoredShots -notcontains $_.FullName } |
                    ForEach-Object { try { Recycle-File $_.FullName; $rm++ } catch { } }
            } catch { }
        }
        if ($rm -gt 0) { Add-Feed ($rm.ToString() + ' old screenshot(s) recycled') }
    } catch { }
}

        $h = $script:ui.ClipHost
        $h.Children.Clear()
        foreach ($c in $script:Clip) {
            $visual = $null; $tip = ''
            if ($c.Kind -eq 'image') {
                $visual = New-ImageEl ([string]$c.Path) 140 58 40 'UniformToFill'
                $tip = ([string]$c.Text + '  ·  double-click pastes')
            } elseif ($c.Kind -eq 'files') {
                $tb = New-Object System.Windows.Controls.TextBlock
                $tb.Text = ('📁 ' + @(($c.Text -split "`n")).Count + ' file(s)')
                $tb.FontSize = 9; $tb.Foreground = (Brush '#C7CDDB'); $tb.TextWrapping = 'Wrap'
                $tb.Width = 56; $tb.TextAlignment = 'Center'; $tb.Margin = (New-Object System.Windows.Thickness 0,10,0,0)
                $visual = $tb; $tip = $c.Text
            } else {
                $flat = ($c.Text -replace '\s+', ' ')
                $isLink = $flat -match '^(https?://|www\.)'
                $disp = $flat
                if ($isLink) { $disp = ($disp -replace '^https?://', '' -replace '^www\.', '') }
                if ($disp.Length -gt 20) { $disp = $disp.Substring(0, 19) + '…' }
                $tb = New-Object System.Windows.Controls.TextBlock
                $tb.Text = $disp
                $tb.FontSize = 8.5; $tb.Foreground = ($(if ($isLink) { (Brush '#7CC5FF') } else { (Brush '#C7CDDB') }))
                $tb.TextWrapping = 'Wrap'; $tb.Width = 56; $tb.TextAlignment = 'Center'
                $tb.Margin = (New-Object System.Windows.Thickness 0,6,0,0)
                $visual = $tb; $tip = $flat.Substring(0, [Math]::Min(80, $flat.Length)) + '  ·  double-click pastes'
            }
            $tile = New-Tile 60 46 $visual $tip @{ Click = 'clipcopy'; Dbl = 'clippaste'; Item = $c } @(
                @{ Text = 'paste now (ctrl+v)'; Action = 'clippaste';  Item = $c }
                @{ Text = 'copy to clipboard';  Action = 'clipcopy';   Item = $c }
                @{ Text = 'forget';             Action = 'clipremove'; Item = $c }
            )
            Wire-Tile $tile
            $h.Children.Add($tile) | Out-Null
        }
        Set-EmptyHint 'ClipEmptyHint' ($h.Children.Count -eq 0)
    } catch { Log-Crash 'clip-shelf' $_.Exception.Message }
}
function Prune-ClipboardImages {
    try {
        $cut = (Get-Date).AddHours(-[double]$script:Settings.RetainHrs)
        $keep = @()
        foreach ($c in $script:Clip) {
            if ($c.Kind -eq 'image' -and $c.Time -lt $cut) { try { Remove-Item -LiteralPath $c.Path -Force -EA SilentlyContinue } catch { } }
            else { $keep += $c }
        }
        if ($keep.Count -ne $script:Clip.Count) { $script:Clip = $keep; Update-ClipboardShelf }
    } catch { }
}

function Clear-ClipboardShelf {
    foreach ($c in $script:Clip) { if ($c.Kind -eq 'image' -and $c.Path) { try { Remove-Item -LiteralPath $c.Path -Force -EA SilentlyContinue } catch { } } }
    $script:Clip = @(); $script:ClipSig = ''
    Update-ClipboardShelf
    Show-Toast 'clipboard shelf cleared'
}

# -------------------------------------------------------------- alerts -----
$script:Alerts = @()
$script:Cool = @{}
$script:HotMem = 0; $script:HotCpu = 0; $script:AlertCycle = 0
function Raise-Alert {
    param([string]$key, [string]$msg, [int]$silenceMin = 30)
    $now = Get-Date
    if ($script:Cool.ContainsKey($key) -and $now -lt $script:Cool[$key]) { return }
    $script:Cool[$key] = $now.AddMinutes($silenceMin)
    $script:Alerts = @(('[' + $now.ToString('HH:mm') + '] ' + $msg)) + @($script:Alerts)
    if ($script:Alerts.Count -gt 12) { $script:Alerts = @($script:Alerts[0..11]) }
    Show-Toast $msg
    $ui = $script:ui
    if ($ui.AlertChip) { $ui.AlertChip.Visibility = 'Visible' }
    if ($ui.AlertText) { $ui.AlertText.Text = ($script:Alerts.Count.ToString() + ' alert' + $(if ($script:Alerts.Count -gt 1) { 's' } else { '' })) }
}
function Next-Alert {
    if ($script:Alerts.Count -eq 0) { return }
    $script:AlertCycle = ($script:AlertCycle + 1) % $script:Alerts.Count
    Show-Toast ('alert ' + ($script:AlertCycle + 1) + '/' + $script:Alerts.Count + '  ·  ' + $script:Alerts[$script:AlertCycle])
}
function Check-Alerts($s) {
    try {
        if (-not $s.NoBattery -and $null -ne $s.BatPct -and -not $s.AC -and -not $s.Charging) {
            if     ($s.BatPct -le 5)  { Raise-Alert 'bat5'   ('BATTERY CRITICAL · ' + ([int]$s.BatPct) + '% · plug in now') 10 }
            elseif ($s.BatPct -le 20) { Raise-Alert 'bat20'  ('battery low · ' + ([int]$s.BatPct) + '% · plug in soon')     30 }
        }
        if ($s.DiskTotal -gt 0 -and $s.DiskFree -lt 8) { Raise-Alert 'disk' ('disk almost full · ' + ([int]$s.DiskFree) + ' GB free on C: · time to clean up') 360 }
        if ($s.Mem -ge 93) { $script:HotMem++ } else { $script:HotMem = 0 }
        if ($script:HotMem -ge 6) { $script:HotMem = 0; Raise-Alert 'mem' 'memory nearly exhausted · click the MEMORY tile for Task Manager' 30 }
        if ($null -ne $s.Temp -and $s.Temp -ge 92) { Raise-Alert 'temp' ('running hot · ' + ([int]$s.Temp) + '°C · check vents / fans') 20 }
    } catch { }
}
$script:LastHw = (Get-Date).AddDays(-99)
function Check-HardwareEvents {
    try {
        if ((Get-Date) -lt $script:LastHw.AddHours(1)) { return }
        $script:LastHw = Get-Date
        try {
            foreach ($d in @(Get-PhysicalDisk -EA Stop | Where-Object { $_.HealthStatus -and $_.HealthStatus -ne 'Healthy' -and ('' + $_.HealthStatus) -ne 'Unknown' -and $_.BusType -ne 'Iscsi' })) {
                Raise-Alert ('disk' + $d.DeviceId) ('disk health · ' + $d.FriendlyName + ' reports ' + $d.HealthStatus + ' · back up your data') 1440
            }
        } catch { }
        try {
            $ev = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; Level = 1, 2, 3; StartTime = (Get-Date).AddHours(-1); ProviderName = 'disk', 'Ntfs', 'stornvme', 'storahci', 'volsnap' } -MaxEvents 3 -EA Stop)
            foreach ($x in $ev) {
                $first = (($x.Message -split "`r?`n")[0])
                if ($first.Length -gt 80) { $first = $first.Substring(0, 80) }
                Raise-Alert ('ev' + $x.Provider.Name + $x.Id) ('hardware event · ' + $x.Provider.Name + ' · ' + $first) 720
            }
        } catch { }
    } catch { }
}

# ------------------------------------------------- timers for the engine ---
$script:ShotTimer = New-Object System.Windows.Threading.DispatcherTimer
$script:ShotTimer.Interval = [TimeSpan]::FromSeconds(5)
$script:ShotTimer.Add_Tick({
    try {
        if ($script:State -eq 'expanded') {
            Update-Screenshots
            if ($script:ClipDirty) { Update-ClipboardShelf }
        }
        # auto-clean & retentions run regardless of open state
        Update-SnapRetentionPurge
    } catch { Log-Crash 'shot' ($_.InvocationInfo.ScriptLineNumber.ToString() + ' ' + $_.Exception.Message) }
})

# ============================================================================
# PART 3 · wiring, behaviour, launch
# ============================================================================

# ------------------------------------------------------------ geometry ----
$script:W = [System.Windows.SystemParameters]::PrimaryScreenWidth
$script:H = [System.Windows.SystemParameters]::PrimaryScreenHeight
if ($AnchorX -ge 0 -and $AnchorY -ge 0) {
    $script:CX = $AnchorX; $script:CY = $AnchorY
} else {
    $script:CX = $script:W / 2; $script:CY = 16
    if ($AnchorX -ge 0) { $script:CX = $AnchorX }
    if ($AnchorY -ge 0) { $script:CY = $AnchorY }
}
$window.Left = $script:CX - $script:PW / 2
$window.Top  = $script:CY - 70          # drop-in from above
$window.Opacity = $script:Settings.Opacity

# ------------------------------------------------------ window styles -----
Add-Type @"
using System;
using System.Runtime.InteropServices;
namespace Island {
    public static class Win {
        const int GWL_EXSTYLE = -20;
        const int WS_EX_TOOLWINDOW = 0x00000080;
        const int WS_EX_NOACTIVATE = 0x08000000;
        [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr hwnd, int idx);
        [DllImport("user32.dll")] static extern int SetWindowLong(IntPtr hwnd, int idx, int val);
        public static void Style(IntPtr h) {
            int v = GetWindowLong(h, GWL_EXSTYLE);
            SetWindowLong(h, GWL_EXSTYLE, v | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE);
        }
        [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
        [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
        [DllImport("user32.dll")] static extern int GetSystemMetrics(int i);
        [DllImport("user32.dll")] public static extern bool AddClipboardFormatListener(IntPtr h);
        [DllImport("user32.dll")] public static extern bool RemoveClipboardFormatListener(IntPtr h);
        public static bool CoveringPrimary() {
            IntPtr h = GetForegroundWindow();
            if (h == IntPtr.Zero) { return false; }
            RECT r;
            if (!GetWindowRect(h, out r)) { return false; }
            int style = GetWindowLong(h, -16);
            if ((style & 0x00100000) != 0) { return false; }   // WS_MAXIMIZE set  -> normal maximized window (incl. UWP), never hide for it
            if ((style & 0x00C00000) != 0) { return false; }   // WS_CAPTION set   -> has a title bar      -> not fullscreen
            int w = GetSystemMetrics(0), hh = GetSystemMetrics(1);
            return r.Left <= 2 && r.Top <= 2 && (r.Right - r.Left) >= (w - 8) && (r.Bottom - r.Top) >= (hh - 8);
        }
    }
    public static class HK {
        [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr h, int id, uint fs, uint vk);
    }
}
"@

# ------------------------------------------------------------ hover -------
$script:Hovering = $false
$script:PinOpen  = $false
$uiCard = $script:ui.Card

$uiCard.Add_MouseEnter({
    $script:Hovering = $true
    if ($script:LeaveTimer) { $script:LeaveTimer.Stop() }
    if ($script:Settings.HoverOpen) { Invoke-State 'expanded' }
})
$uiCard.Add_MouseLeave({
    $script:Hovering = $false
    if (-not $script:LeaveTimer) {
        $lt = New-Object System.Windows.Threading.DispatcherTimer
        $lt.Interval = [TimeSpan]::FromMilliseconds(380)
        $lt.Add_Tick({ param($snd)
            $snd.Stop()
            if ($script:Settings.HoverOpen -and -not $script:PinOpen -and -not $script:ui.Card.IsMouseOver -and (Get-Date) -gt $script:HoldUntil) {
                Invoke-State 'collapsed'
            }
        })
        $script:LeaveTimer = $lt
    }
    if ($script:Settings.HoverOpen -and -not $script:PinOpen) { $script:LeaveTimer.Stop(); $script:LeaveTimer.Start() }
})

# drag anywhere on the island; a tap (no movement) toggles pin-open state
$uiCard.Add_MouseLeftButtonDown({
    param($sender, $e)
    # a press that lands on a tile (anything carrying a Tag) belongs to the tile, not the drag
    $o = $e.OriginalSource
    while ($o -and -not ($o -is [System.Windows.Window])) {
        if ($o.Tag) { return }
        try { $o = [System.Windows.Media.VisualTreeHelper]::GetParent($o) } catch { return }
    }
    $x0 = $window.Left; $y0 = $window.Top
    try { $window.DragMove() } catch { return }
    $moved = [Math]::Abs($window.Left - $x0) + [Math]::Abs($window.Top - $y0)
    if ($moved -lt 3) {
        if ($script:State -eq 'collapsed' -or -not $script:PinOpen) {
            $script:PinOpen = $true
            Invoke-State 'expanded'
            $script:HoldUntil = (Get-Date)
        } else {
            $script:PinOpen = $false
            Invoke-State 'collapsed'
        }
    }
    $script:CX = $window.Left + $window.Width / 2
    $script:CY = [Math]::Max(-2, [Math]::Min($script:H - 80, $window.Top))
})

# ============================================================ PAGES =========
$script:Page  = 'home'
$script:Pages = @{
    home    = 'PageGroups'
    stats   = 'PageStats'
    clip    = 'PageClip'
    snaps   = 'PageSnaps'
    apps    = 'PageApps'
    alerts  = 'PageAlerts'
    actions = 'PageActions'
    reminders = 'PageReminders'
    focus   = 'PageFocus'
    settings  = 'PageSettings'
}
$script:PageH = @{ focus=492; home=462; stats=512; clip=262; snaps=262; apps=262; alerts=330; reminders=312; actions=406; settings=560 }
$script:PageTitles = @{ stats='S Y S T E M   S T A T S'; clip='C L I P B O A R D'; snaps='S N A P S'; apps='A P P S'; alerts='A L E R T S'; actions='A C T I O N S'; reminders='R E M I N D E R S'; focus='F O C U S'; settings='S E T T I N G S' }
function Show-Page([string]$name) {
    if (-not $script:Pages.ContainsKey($name)) { return }
    $script:Page = $name
    foreach ($k in $script:Pages.Keys) {
        $pg = $script:ui[$script:Pages[$k]]
        if ($pg) {
            if ($k -eq $name) {
                $pg.Visibility = 'Visible'
                $pg.Opacity = 0
                Anim-El $pg ([System.Windows.UIElement]::OpacityProperty) 1 190
            } else {
                $pg.Visibility = 'Collapsed'
            }
        }
    }
    $bs = $script:ui.BackStrip
    if ($bs) { $bs.Visibility = $(if ($name -eq 'home') { 'Collapsed' } else { 'Visible' }) }
    $tt = $script:ui.TxtPageTitle
    if ($tt) { $tt.Text = [string]$script:PageTitles[$name] }
    if ($name -eq 'alerts') { Refresh-AlertPage }
    if ($name -eq 'settings') { Render-SettingsPage }
    if ($name -eq 'reminders') { Render-RemindersPage }
    if ($name -eq 'focus') { Render-Focus }
    $ph = $script:PageH[$name]
    if ($ph -and [double]$ph -ne [double]$script:EH) {
        $script:EH = [double]$ph
        if ($script:State -eq 'expanded') { Invoke-State 'expanded' -force $true -sizeonly $true }
    }
    if ($name -eq 'clip')   { Update-ClipboardShelf }
    if ($script:ClipDirty) { $script:ClipDirty = $false; Update-ClipboardShelf; $script:ShotSig = ''; Update-Screenshots }
    if ($name -eq 'snaps')  { $script:ShotSig = ''; Update-Screenshots }
    if ($name -eq 'apps')   { Update-Launchers }
}
function Refresh-AlertPage {
    try {
        $h = $script:ui.AlertHost
        if (-not $h) { return }
        $h.Children.Clear()
        if ($script:Alerts.Count -eq 0) {
            $tb = New-Object System.Windows.Controls.TextBlock
            $tb.Text = 'no alerts · all clear'
            $tb.FontSize = 11.5; $tb.Foreground = (Brush '#5F6878'); $tb.Margin = (New-Object System.Windows.Thickness 4,10,0,0)
            $h.Children.Add($tb) | Out-Null
            return
        }
        foreach ($a in $script:Alerts) {
            $row = New-Object System.Windows.Controls.Border
            $row.Background = (Brush '#12FFB26B'); $row.CornerRadius = 8
            $row.Padding = (New-Object System.Windows.Thickness 10,5,10,5)
            $row.Margin = (New-Object System.Windows.Thickness 0,2,0,2)
            $tb = New-Object System.Windows.Controls.TextBlock
            $tb.Text = $a; $tb.FontSize = 10.5; $tb.FontFamily = (New-Object System.Windows.Media.FontFamily 'Cascadia Mono, Consolas')
            $tb.Foreground = (Brush '#FFCC94'); $tb.TextWrapping = 'Wrap'
            $row.Child = $tb
            $h.Children.Add($row) | Out-Null
        }
    } catch { Log-Crash 'alert-page' $_.Exception.Message }
}

# ---------- home layout: list <-> grid (content swap inside one ScrollViewer) ----------
$script:HomeRowOrder = @('TileGStats','TileGClip','TileGSnaps','TileGApps','TileGRem','TileGFocus','TileGAlerts','TileGActions','TileGSet')
$script:InGrid = $false
$script:GridDocked = $false
function Move-Row([System.Windows.UIElement]$el, $from, $to) {
    try {
        if ($null -eq $el) { return }
        $parent = $el.Parent
        if ($parent -and ($parent -is [System.Windows.Controls.UIElementCollection])) { }
        if ($parent) { $pc = $parent.GetType() }
        if ($from -and $from.Children.IndexOf($el) -ge 0) { $from.Children.Remove($el) | Out-Null }
        $p2 = $el.Parent
        if ($p2 -and ($p2 -ne $to)) {
            # element still attached (to unexpected panel): detach generically
            $coll = $p2.GetValue([System.Windows.Controls.Panel]::ChildrenProperty)
            if ($coll) { $coll.Remove($el) | Out-Null }
        }
        if ($to.Children.IndexOf($el) -lt 0) { $to.Children.Add($el) | Out-Null }
    } catch { Log-Crash 'move-row' $_.Exception.Message }
}
function Apply-HomeLayout {
    try {
        $list = $script:ui.HomeList
        $grid = $script:ui.HomeGrid
        $scr  = $script:ui.HomeScroll
        $dock = $script:ui.HomeGridDock
        if (-not $list -or -not $grid -or -not $scr) { return }
        if (-not $script:GridDocked) {
            # detach HomeGrid from its dock ONCE so it is parentless and safe to assign as Content
            try { $dock.Children.Remove($grid) | Out-Null } catch { }
            $script:GridDocked = $true
        }
        $wantGrid = (([string]$script:Settings.HomeLayout) -eq 'grid')
        $cur = $(if ($scr.Content -eq $grid) { 'grid' } else { 'list' })
        if ($wantGrid -and ($cur -ne 'grid')) {
            foreach ($rn in $script:HomeRowOrder) { Move-Row $script:ui[$rn] $list $grid }
            $scr.Content = $grid
            $script:InGrid = $true
        } elseif ((-not $wantGrid) -and ($cur -ne 'list')) {
            if (-not $script:HomeSpacer) {
                $sp = New-Object System.Windows.Controls.Border
                $sp.Height = 16; $sp.Background = ([System.Windows.Media.Brushes]::Transparent)
                $script:HomeSpacer = $sp
            }
            $spacer = $script:HomeSpacer
            foreach ($rn in $script:HomeRowOrder) {
                $el = $script:ui[$rn]
                if ($rn -eq 'TileGActions') { if ($list.Children.IndexOf($spacer) -lt 0) { $list.Children.Add($spacer) | Out-Null } }
                Move-Row $el $grid $list
            }
            $scr.Content = $list
            $script:InGrid = $false
        }
        $scr.ScrollToTop()
    } catch { Log-Crash 'layout' $_.Exception.Message }
}

# ============================================================ FOCUS =========
# state: Mode idle|run|pause · End = deadline · Goal = selected preset (min)
$script:Fo  = @{ Mode='idle'; End=$null; Goal=25; Left=1500 }
function Get-ArcGeometry([double]$frac, [double]$r) {
    # clockwise arc starting at 12 o'clock, ~full sweep handled with two segments
    if ($frac -le 0.001) { return 'M 0 0' }
    $cx = 100.0; $cy = 100.0
    $frac = [Math]::Min($frac, 0.9997)
    $a0 = -90.0
    $a1 = $a0 + 360.0 * $frac
    $x0 = ($cx + $r * [Math]::Cos(($a0) * [Math]::PI / 180.0))
    $y0 = ($cy + $r * [Math]::Sin(($a0) * [Math]::PI / 180.0))
    $parts = @()
    $rem = $frac
    $curA = $a0
    while ($rem -gt 0.0005) {
        $seg = [Math]::Min($rem, 0.499)
        $nA = $curA + 360.0 * $seg
        $x1 = ($cx + $r * [Math]::Cos(($nA) * [Math]::PI / 180.0))
        $y1 = ($cy + $r * [Math]::Sin(($nA) * [Math]::PI / 180.0))
        $parts += ('A {0} {0} 0 0 1 {1} {2}' -f $r, [Math]::Round($x1,2), [Math]::Round($y1,2))
        $curA = $nA; $rem -= $seg
    }
    return (('M {0} {1} ' -f [Math]::Round($x0,2), [Math]::Round($y0,2)) + ($parts -join ' '))
}
function Render-Focus {
    try {
        $u = $script:ui
        $state = $u.FoState; $big = $u.FoBig; $arc = $u.FoArc
        $m = [string]$script:Fo.Mode
        $left = [int]$script:Fo.Left
        if ($m -eq 'run') { $left = [Math]::Max(0, [int](($script:Fo.End - (Get-Date)).TotalSeconds)) }
        $mm = [int][Math]::Floor($left / 60); $ss = $left % 60
        if ($big) {
            $big.Text = ('{0:D2}:{1:D2}' -f $mm, $ss)
            $big.Foreground = $(if ($m -eq 'pause') { (Brush '#8E939C') } else { (Brush '#F3F4F6') })
        }
        $frac = if ([int]$script:Fo.Goal -gt 0) { [double]$left / ([int]$script:Fo.Goal * 60.0) } else { 0 }
        if ($arc) { try { $arc.Data = [System.Windows.Media.Geometry]::Parse((Get-ArcGeometry $frac 95.0)) } catch { } }
        if ($state) { $state.Text = switch ($m) { 'run'   { ('F O C U S  ·  ends ' + $script:Fo.End.ToString('HH:mm')) }
                                                   'pause' { 'R E S T I N G' }
                                                   default { 'F O C U S' } } }
        $sl = $u.FoStartTxt
        if ($sl) { $sl.Text = switch ($m) { 'run' { 'PAUSE' } 'pause' { 'RESUME' } default { 'BEGIN' } } }
        foreach ($cn in @('Fo15','Fo25','Fo45','Fo60')) {
            $bq = $u[$cn]
            if ($bq) {
                $val = [int]($cn.Substring(2))
                $bq.Background = $(if ($val -eq [int]$script:Fo.Goal -and $m -eq 'idle') { (Brush '#26FFFFFF') } else { (Brush '#0EFFFFFF') })
            }
        }
        $gp = $u.GFocusPrev
        if ($gp) { $gp.Text = switch ($m) { 'run' { $mm.ToString() + ':' + $ss.ToString('D2') + ' left' } 'pause' { 'paused · ' + $mm + 'm' } default { $script:Fo.Goal.ToString() + ' min ready' } } }
    } catch { Log-Crash 'focus-render' $_.Exception.Message }
}
function Fo-Tick {
    try {
        if ([string]$script:Fo.Mode -ne 'run') { return }
        $left = [int](($script:Fo.End - (Get-Date)).TotalSeconds)
        if ($left -le 0) {
            $script:Fo.Mode = 'idle'; $script:Fo.Left = [int]$script:Fo.Goal * 60
            Raise-Alert 'focusdone' ('focus complete · ' + $script:Fo.Goal + ' min done — step away, hydrate') 2
            Render-Focus
            return
        }
        $script:Fo.Left = $left
        Render-Focus
        # live-bar ownership while a session is running
        if ((Get-Date) -gt $script:HoldUntil -and $script:State -eq 'collapsed') { }
    } catch { }
}
foreach ($fn2 in @('Fo15','Fo25','Fo45','Fo60')) {
    $bx = $script:ui[$fn2]
    if ($bx) {
        $bx.Tag = 'ui'
        $bx.Add_PreviewMouseLeftButtonUp({ param($snd, $e)
            $e.Handled = $true
            if ([string]$script:Fo.Mode -ne 'idle') { return }
            $script:Fo.Goal = [int](([string]$snd.Name).Substring(2))
            $script:Fo.Left = [int]$script:Fo.Goal * 60
            Render-Focus
        })
    }
}
$bStart = $script:ui.FoStart
if ($bStart) {
    $bStart.Tag = 'ui'
    $bStart.Add_PreviewMouseLeftButtonUp({ param($snd, $e)
        $e.Handled = $true
        $m = [string]$script:Fo.Mode
        if ($m -eq 'idle')           { $script:Fo.Mode = 'run';   $script:Fo.End = (Get-Date).AddSeconds([int]$script:Fo.Goal * 60) }
        elseif ($m -eq 'run')        { $script:Fo.Mode = 'pause'; $script:Fo.Left = [int](($script:Fo.End - (Get-Date)).TotalSeconds) }
        elseif ($m -eq 'pause')      { $script:Fo.Mode = 'run';   $script:Fo.End = (Get-Date).AddSeconds([int]$script:Fo.Left) }
        Render-Focus
    })
}
$bReset = $script:ui.FoReset
if ($bReset) {
    $bReset.Tag = 'ui'
    $bReset.Add_PreviewMouseLeftButtonUp({ param($snd, $e)
        $e.Handled = $true
        $script:Fo.Mode = 'idle'; $script:Fo.Left = [int]$script:Fo.Goal * 60
        Render-Focus
    })
}

# group tile clicks
$groupMap = @{ TileGStats='stats'; TileGClip='clip'; TileGSnaps='snaps'; TileGApps='apps'; TileGAlerts='alerts'; TileGActions='actions'; TileGRem='reminders'; TileGFocus='focus'; TileGSet='settings' }
foreach ($g in $groupMap.Keys) {
    $el = $script:ui[$g]
    if ($el) {
        # destination travels in the tile's own Tag - never a loop variable!
        $el.Tag = @{ Dest = $groupMap[$g] }
        $el.Add_PreviewMouseLeftButtonUp({
            param($snd, $e)
            $e.Handled = $true
            Show-Page ([string]$snd.Tag.Dest)
        })
    }
}
$bb = $script:ui.BtnBack
if ($bb) {
    $bb.Tag = 'ui'
    $bb.Add_PreviewMouseLeftButtonUp({ param($snd, $e) $e.Handled = $true; Show-Page 'home' })
}
$seen = $script:ui.BtnAlertSeen
if ($seen) {
    $seen.Tag = 'ui'
    $seen.Add_PreviewMouseLeftButtonUp({
        param($snd, $e)
        $e.Handled = $true
        $script:Alerts = @()
        $c = $script:ui.AlertChip; if ($c) { $c.Visibility = 'Collapsed' }
        Refresh-AlertPage
    })
}

# actions page wiring
function Run-IslandAction([string]$which) {
    try {
        switch ($which) {
            'A_taskmgr'  { Start-Process taskmgr }
            'A_capture'  { Take-Screenshot }
            'A_clippage' { Show-Page 'clip' }
            'A_apppage'  { Browse-Launchers }
            'A_net'      { $null = [System.Diagnostics.Process]::Start('ncpa.cpl') }
            'A_batt'     { $null = [System.Diagnostics.Process]::Start('ms-settings:batterysaver') }
            'A_restart'  { $self = Get-ExePath; $null = Start-Process powershell.exe -WindowStyle Hidden -ArgumentList ('-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f $self),'-Minimized','-Kill') }
            'A_color'    { $keys=@('mono','aurora','cyber','flux','ember','amber','reef'); $ix=[array]::IndexOf($keys,[string]$script:Settings.Accent); if ($ix -lt 0){$ix=0}; $script:Settings.Accent=$keys[($ix+1)%$keys.Length]; Save-Settings; Show-Toast ('accent · ' + $script:Settings.Accent) }
        }
    } catch { Log-Crash 'action' ($which + ' ' + $_.Exception.Message) }
}
foreach ($an in @('A_taskmgr','A_capture','A_clippage','A_apppage','A_net','A_batt','A_restart','A_color')) {
    $ael = $script:ui[$an]
    if ($ael) {
        $ael.Tag = 'ui'
        $ael.Add_PreviewMouseLeftButtonUp({
            param($snd, $e)
            $e.Handled = $true
            Run-IslandAction ([string]$snd.Name)
        })
    }
}


# ========================================================== REMINDERS ========
$script:ClipDirty = $false
$script:Ver  = '15'
$script:FSCnt= 0; $script:FSOff = 0; $script:HbCnt = 0; $script:Parked = $false
function Park-Island {
    $script:Parked = $true
    try {
        $window.BeginAnimation([System.Windows.Window]::TopProperty, $null)
        $window.Top = -9999
    } catch { }
}
function UnPark-Island {
    $script:Parked = $false
    try {
        $window.Top = $script:CY
    } catch { }
}
$script:Snooze   = @()
$script:RemFired = @{}
function Get-NormReminders {
    $out = @()
    foreach ($r in @($script:Settings.Reminders)) {
        try {
            if ($r -is [hashtable]) { $txt = [string]$r['Text']; $tm = [string]$r['Time']; $en = ($r['Enabled'] -ne $false) }
            else { $txt = [string]$r.Text; $tm = [string]$r.Time; $en = ($r.Enabled -ne $false) }
            if ($txt -and $tm -match '^\d{2}:\d{2}$') { $out += @{ Text = $txt; Time = $tm; Enabled = $en } }
        } catch { }
    }
    return ,@($out)
}
function Add-Reminder {
    try {
        $t = [Microsoft.VisualBasic.Interaction]::InputBox('What should Island remind you to do?', 'New reminder', 'Stand up and stretch')
        if (-not $t) { return }
        $def = (Get-Date).AddMinutes(5).ToString('HH:mm')
        $h = [Microsoft.VisualBasic.Interaction]::InputBox('At what time? (HH:mm, 24h, repeats daily)', 'Reminder time', $def)
        if ($h -notmatch '^\s*(\d{1,2})\s*:\s*(\d{1,2})\s*$') { Show-Toast 'bad time - use HH:mm like 09:30'; return }
        $hh = [int]$Matches[1]; $mi = [int]$Matches[2]
        if ($hh -gt 23 -or $mi -gt 59) { Show-Toast 'bad time - use HH:mm like 09:30'; return }
        $list = @(Get-NormReminders)
        $list += @{ Text = (($t -replace '[\r\n]+',' ') -replace '[<>]','').Trim(); Time = ('{0:D2}:{1:D2}' -f $hh, $mi); Enabled = $true }
        $script:Settings.Reminders = $list
        Save-Settings; Render-RemindersPage
        Show-Toast ('reminder set - ' + ('{0:D2}:{1:D2}' -f $hh, $mi) + ' daily')
    } catch { Log-Crash 'reminder-add' $_.Exception.Message }
}
function Delete-Reminder([string]$time, [string]$text) {
    $script:Settings.Reminders = @(Get-NormReminders | Where-Object { -not ($_.Time -eq $time -and $_.Text -eq $text) })
    Save-Settings; Render-RemindersPage
}
function Render-RemindersPage {
    try {
        $h = $script:ui.RemindHost
        if (-not $h) { return }
        $h.Children.Clear()
        $arr = @(Get-NormReminders)
        foreach ($r in $arr) {
            $row = New-Object System.Windows.Controls.Border
            $row.Background = (Brush '#10FFFFFF'); $row.CornerRadius = 10
            $row.Padding = (New-Object System.Windows.Thickness 12,7)
            $row.Margin  = (New-Object System.Windows.Thickness 0,2,0,2)
            $row.Cursor = 'Hand'; $row.Tag = @{ Time = $r.Time; Text = $r.Text }
            $tb = New-Object System.Windows.Controls.TextBlock
            $tb.Text = $r.Time + '  ·  ' + $r.Text + $(if ($r.Enabled -eq $false) { '   (paused)' } else { '' })
            $tb.FontSize = 11.5; $tb.Foreground = (Brush $(if ($r.Enabled -eq $false) { '#66708a' } else { '#C9CFDC' }))
            $tb.FontFamily = (New-Object System.Windows.Media.FontFamily 'Cascadia Mono, Consolas')
            $tb.TextWrapping = 'Wrap'
            $row.Child = $tb
            $row.ToolTip = 'tap to delete'
            $row.Add_PreviewMouseLeftButtonUp({ param($snd, $e)
                $e.Handled = $true
                Delete-Reminder ([string]$snd.Tag.Time) ([string]$snd.Tag.Text)
                Show-Toast 'reminder removed'
            })
            $h.Children.Add($row) | Out-Null
        }
        if ($arr.Count -eq 0) {
            $tb = New-Object System.Windows.Controls.TextBlock
            $tb.Text = 'no reminders yet - add one below'
            $tb.FontSize = 11; $tb.Foreground = (Brush '#4E5666'); $tb.Margin = (New-Object System.Windows.Thickness 4,12,0,0)
            $h.Children.Add($tb) | Out-Null
        }
        $g = $script:ui.GRemPrev
        if ($g) { $g.Text = $(if ($arr.Count) { $arr.Count.ToString() + ' scheduled' } else { 'none yet' }) }
    } catch { Log-Crash 'rem-render' $_.Exception.Message }
}
function Ask-Reminder([string]$text, [string]$time) {
    try {
        Show-Toast ('reminder - ' + $time)
        $res = [System.Windows.MessageBox]::Show($window, ($text + "`r`n`r`nCompleted?"), ('Island · ' + $time), 'YesNo', 'Question')
        if ($res -eq [System.Windows.MessageBoxResult]::Yes) { Add-Feed ('done: ' + $text) }
        else {
            $script:Snooze = @($script:Snooze) + @(@{ Text = $text; Time = $time; Due = (Get-Date).AddMinutes(10) })
            Add-Feed 'reminder snoozed 10 min'
        }
    } catch { Show-Toast $text }
}
function Check-Reminders($now) {
    try {
        $hhmm = $now.ToString('HH:mm'); $dkey = $now.ToString('yyyy-MM-dd')
        foreach ($r in @(Get-NormReminders)) {
            if ($r.Enabled -eq $false) { continue }
            if ($r.Time -ne $hhmm) { continue }
            $k = $dkey + '|' + $r.Time + '|' + $r.Text
            if ($script:RemFired.ContainsKey($k)) { continue }
            $script:RemFired[$k] = $true
            Ask-Reminder $r.Text $r.Time
        }
        foreach ($dn in @($script:Snooze)) {
            if ((Get-Date) -ge $dn.Due) {
                $script:Snooze = @($script:Snooze | Where-Object { $_.Due -ne $dn.Due })
                Ask-Reminder ([string]$dn.Text) ([string]$dn.Time)
            }
        }
    } catch { Log-Crash 'rem-check' $_.Exception.Message }
}

# ========================================================== SETTINGS =========
function VV([string]$n, [string]$t) { $el = $script:ui[$n]; if ($el) { $el.Text = $t } }
function BoolTxt($v) { if ([bool]$v) { 'ON' } else { 'off' } }
function Render-SettingsPage {
    try {
        $S = $script:Settings
        VV 'V_hover'  (BoolTxt $S.HoverOpen)
        VV 'V_full'   (BoolTxt $S.HideOnFS)
        VV 'V_top'    (BoolTxt $S.Topmost)
        VV 'V_layout' ([string]$S.HomeLayout)
        VV 'V_auto'   $(if (Test-RunAtStartup) { 'ON' } else { 'off' })
        VV 'V_accent' ('*' + [string]$S.Accent)
        VV 'V_scrub'  (BoolTxt $S.ScrubShots)
        VV 'V_data'   ''
        VV 'V_reset'  ''
        Update-SettingsCaptions
        $script:SliderQuiet = $true
        $sl = $script:ui.Sld_opaque; if ($sl) { $sl.Value = [double]([Math]::Round(([double]$S.Opacity*100),0)) }
        $sl = $script:ui.Sld_width;  if ($sl) { $sl.Value = [double]([Math]::Round(([double]$S.WidthScale*100),0)) }
        $sl = $script:ui.Sld_speed;  if ($sl) { $sl.Value = [double]([int]$S.AnimMs) }
        $sl = $script:ui.Sld_retain; if ($sl) { $sl.Value = [double]([int]$S.RetainHrs) }
    } catch { }
    finally { $script:SliderQuiet = $false }
    $g = $script:ui.GSetPrev; if ($g) { $g.Text = 'behavior · look · data' }
}
function Update-SettingsCaptions {
    try {
        $S = $script:Settings
        VV 'V_opaque' ((([int]([Math]::Round([double]$S.Opacity*100,0)))).ToString() + '%')
        VV 'V_width'  ((([int]([Math]::Round([double]$S.WidthScale*100,0)))).ToString() + '%')
        VV 'V_speed'  (([int]$S.AnimMs).ToString() + 'ms')
        VV 'V_retain' (([int]$S.RetainHrs).ToString() + 'h')
    } catch { }
}

function Apply-Settings {
    try {
        $window.Topmost = [bool]$script:Settings.Topmost
        $window.Opacity = [double]$script:Settings.Opacity
        $ec = $false
        $base = $(if ($ec) { 620.0 } else { 480.0 })
        $script:EW = [double]([int](430.0 * [double]$script:Settings.WidthScale))
        Invoke-State $script:State -force $true
    } catch { }
}
function Run-Setting([string]$n) {
    try {
        switch ($n) {
            'ST_hover' { $script:Settings.HoverOpen  = -not [bool]$script:Settings.HoverOpen;  Save-Settings }
            'ST_full'  { $script:Settings.HideOnFS    = -not [bool]$script:Settings.HideOnFS;  Save-Settings; if ($window.Visibility -ne 'Visible') { $window.Visibility = 'Visible' } }
            'ST_layout'{ $script:Settings.HomeLayout = $(if ([string]$script:Settings.HomeLayout -eq 'list') { 'grid' } else { 'list' }); Save-Settings; Apply-HomeLayout; VV 'V_layout' ([string]$script:Settings.HomeLayout) }
            'ST_top'   { $script:Settings.Topmost     = -not [bool]$script:Settings.Topmost;   Save-Settings; $window.Topmost = [bool]$script:Settings.Topmost }
            'ST_auto'  { $now = -not (Test-RunAtStartup); Set-RunAtStartup $now }
            'ST_accent'{ $keys = @('mono','aurora','cyber','flux','ember','amber','reef'); $ix = [array]::IndexOf($keys, [string]$script:Settings.Accent); if ($ix -lt 0) { $ix = 0 }; $script:Settings.Accent = $keys[($ix + 1) % $keys.Length]; Save-Settings; Invoke-State $script:State -force $true }
            'ST_scrub' { $script:Settings.ScrubShots = -not [bool]$script:Settings.ScrubShots; Save-Settings }
            'ST_data'  { $null = [System.Diagnostics.Process]::Start($script:DataDir) }
            'ST_reset' {
                $res = [System.Windows.MessageBox]::Show($window, 'Reset ALL Island settings?`nPinned launchers and reminders will be cleared.', 'Island', 'YesNo', 'Warning')
                if ($res -eq [System.Windows.MessageBoxResult]::Yes) {
                    try { Remove-Item -LiteralPath $script:ConfFile -Force -EA SilentlyContinue } catch { }
                    $script:Settings.Topmost = $true; $script:Settings.Opacity = 0.96; $script:Settings.HoverOpen = $true
                    $script:Settings.Accent = 'mono'; $script:Settings.ScrubShots = $true; $script:Settings.RetainHrs = 2
                    $script:Settings.Launchers = @(); $script:Settings.Reminders = @(); $script:Settings.HideOnFS = $false; $script:Settings.Wide = $false
                    $script:Settings.WidthScale = 1.0; $script:Settings.AnimMs = 280; $script:Settings.RetainHrs = 2; $script:PW = 208.0
                    $script:IconCache = @{}
                    Save-Settings; Apply-Settings; Update-Launchers
                }
            }
        }
        if ($n -notin @('ST_data','ST_reset')) { Render-SettingsPage }
    } catch { Log-Crash 'setting' ($n + ' ' + $_.Exception.Message) }
}
foreach ($sm in @('ST_hover','ST_full','ST_layout','ST_top','ST_auto','ST_accent','ST_scrub','ST_data','ST_reset')) {
    $sel = $script:ui[$sm]
    if ($sel) {
        $sel.Tag = 'ui'
        $sel.Add_PreviewMouseLeftButtonUp({ param($snd, $e) $e.Handled = $true; Run-Setting ([string]$snd.Name) })
    }
}
# throttled save so dragging a slider never floods disk
$script:SaveDrip = New-Object System.Windows.Threading.DispatcherTimer
$script:SaveDrip.Interval = [TimeSpan]::FromMilliseconds(700)
$script:SaveDrip.Add_Tick({ param($snd) $snd.Stop(); Save-Settings })
foreach ($sn in @('Sld_opaque','Sld_width','Sld_speed','Sld_retain')) {
    $snEl = $script:ui[$sn]
    if ($snEl) {
        $snEl.Tag = 'ui'
        $snEl.Add_ValueChanged({
            param($snd, $ev)
            if ($script:SliderQuiet) { return }
            try {
                $v = [double]$snd.Value
                switch ([string]$snd.Name) {
                    'Sld_opaque' { $script:Settings.Opacity  = [Math]::Round($v/100.0,2); $window.Opacity = [double]$script:Settings.Opacity }
                    'Sld_width'  { $script:Settings.WidthScale = [Math]::Round($v/100.0,2); $script:Settings.Wide = $false
                                   $b = [bool]$script:Settings.Wide; $base = $(if ($b) {620.0} else {480.0})
                                   $script:EW = [double]([int](430.0 * [double]$script:Settings.WidthScale))
                                   $script:ShotSig = ''
                                   if ($script:State -eq 'expanded') { Invoke-State 'expanded' -force $true -sizeonly $true } }
                    'Sld_speed'  { $script:Settings.AnimMs = [int]$v }
                    'Sld_retain' { $script:Settings.RetainHrs = [int]$v; $script:ShotSig = '' }
                }
                Update-SettingsCaptions
                $script:SaveDrip.Stop(); $script:SaveDrip.Start()
            } catch { Log-Crash 'slider' $_.Exception.Message }
        })
    }
}
$BtGear = $script:ui.BtnGear
if ($BtGear) {
    $BtGear.Tag = 'ui'
    $BtGear.Add_PreviewMouseLeftButtonUp({ param($snd, $e) $e.Handled = $true; Show-Page 'settings' })
}
$BtAddR = $script:ui.BtnAddReminder
if ($BtAddR) {
    $BtAddR.Tag = 'ui'
    $BtAddR.Add_PreviewMouseLeftButtonUp({ param($snd, $e) $e.Handled = $true; Add-Reminder })
}

# ----------------------------------------------------- tile actions ---
$tileMap = @{
    TileCpu  = 'taskmgr'
    TileMem  = 'taskmgr'
    TileNet  = 'ncpa.cpl'
    TileSto  = 'shell:ThisPCDesktopFolder'
    TilePwr  = 'ms-settings:batterysaver'
    TileSys  = 'ms-settings:about'
    TileDisp = 'ms-settings:display'
}
foreach ($k in @($tileMap.Keys)) {
    $el = $script:ui[$k]
    if (-not $el) { continue }
    $el.Tag = $tileMap[$k]
    $el.Add_PreviewMouseLeftButtonDown({
        param($sender, $e)
        $e.Handled = $true
        $t = [string]$sender.Tag
        try {
            if     ($t -eq 'taskmgr') { Start-Process taskmgr }
            elseif ($t.StartsWith('shell')) { $null = & explorer.exe $t }
            else { $null = [System.Diagnostics.Process]::Start($t) }
        } catch { }
        $script:PinOpen = $false
        Invoke-State 'collapsed'
    })
}

# ----------------------------------------------------- drag && drop ------
$window.Add_DragOver({
    param($s, $e)
    if ($e.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) {
        $e.Effects = [System.Windows.DragDropEffects]::Copy
    } else {
        $e.Effects = [System.Windows.DragDropEffects]::None
    }
    $e.Handled = $true
})
$window.Add_Drop({
    param($s, $e)
    $e.Handled = $true
    try {
        $files = @($e.Data.GetData([System.Windows.DataFormats]::FileDrop))
        Invoke-State 'expanded'
        $added = 0
        foreach ($f in $files) {
            if (-not $f) { continue }
            $ext = [System.IO.Path]::GetExtension([string]$f).ToLower()
            if ($ext -in @('.lnk', '.url', '.exe')) { Add-Launcher ([string]$f); $added++ }
        }
        if ($added -eq 0 -and $files.Count -gt 0) { Show-Toast 'drop shortcuts (.lnk) to pin apps' }
    } catch { Log-Crash 'drop' $_.Exception.Message }
})

foreach ($bn in @('BtnAddLauncher', 'BtnClearClip', 'AlertChip')) { if ($script:ui[$bn]) { $script:ui[$bn].Tag = 'ui' } }
$script:ui.BtnAddLauncher.Add_PreviewMouseLeftButtonUp({
    param($s, $e)
    $e.Handled = $true
    Browse-Launchers
})
$script:ui.BtnClearClip.Add_PreviewMouseLeftButtonUp({
    param($s, $e)
    $e.Handled = $true
    Clear-ClipboardShelf
})
$fl = $script:ui['FeedPill']
if ($fl) {
    $fl.Tag = 'ui'
    $fl.Add_PreviewMouseLeftButtonUp({ param($snd, $e) $e.Handled = $true; Show-Page 'stats'; $script:PinOpen = $true })
}
$bns = $script:ui['BtnSnap']
if ($bns) {
    $bns.Tag = 'ui'
    $bns.Add_PreviewMouseLeftButtonUp({
        param($s2, $e2)
        $e2.Handled = $true
        Take-Screenshot
    })
}
$script:ui.AlertChip.Add_PreviewMouseLeftButtonUp({
    param($s, $e)
    $e.Handled = $true
    Next-Alert
})

# ----------------------------------------------------- context menu -------
function New-MI([string]$text, [scriptblock]$action) {
    $mi = New-Object System.Windows.Controls.MenuItem
    $mi.Header = $text
    $mi.Add_Click($action)
    return $mi
}
function Get-ExePath { if ($PSCommandPath) { $PSCommandPath } else { 'Island.ps1' } }
function Set-RunAtStartup([bool]$on) {
    $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    try {
        if ($on) {
            $vbs = Join-Path (Split-Path -Parent (Get-ExePath)) 'Island-silent.vbs'
            if (Test-Path $vbs) {
                Set-ItemProperty -Path $key -Name 'IslandPS' -Value ('wscript.exe "' + $vbs + '"')
            } else {
                Set-ItemProperty -Path $key -Name 'IslandPS' -Value ('powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + (Get-ExePath) + '"')
            }
        } else {
            Remove-ItemProperty -Path $key -Name 'IslandPS' -ErrorAction SilentlyContinue
        }
    } catch { }
}
function Test-RunAtStartup {
    try { $null = Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'IslandPS' -ErrorAction Stop; return $true } catch { return $false }
}

$menu = New-Object System.Windows.Controls.ContextMenu
$null = $menu.Items.Add((New-MI 're-dock to top centre' {
    $script:CX = $script:W / 2
    $script:CY = 16
    Invoke-State $script:State -force $true
}))
$null = $menu.Items.Add((New-MI 'pin open  ·  unpin' {
    if ($script:PinOpen) { $script:PinOpen = $false; Invoke-State 'collapsed' }
    else { $script:PinOpen = $true; Invoke-State 'expanded' }
}))
$null = $menu.Items.Add((New-Object System.Windows.Controls.Separator))
foreach ($a in @('mono','aurora','cyber','flux','ember','amber','reef')) {
    $mi = New-Object System.Windows.Controls.MenuItem
    $mi.Header = 'accent · ' + $a
    $mi.Tag   = $a
    $mi.Add_Click({
        $script:Settings.Accent = [string]$sender.Tag
        Save-Settings
    })
    $null = $menu.Items.Add($mi)
}
$null = $menu.Items.Add((New-Object System.Windows.Controls.Separator))
$null = $menu.Items.Add((New-MI 'pin a shortcut to the island…' { Browse-Launchers }))
$script:MiManage = New-Object System.Windows.Controls.MenuItem
$script:MiManage.Header = 'launchers · manage / unpin'
$script:MiManage.Add_SubmenuOpened({
    try {
        $mm = $script:MiManage
        while ($mm.Items.Count -gt 0) { $mm.Items.RemoveAt(0) }
        $arr = @($script:Settings.Launchers)
        if ($arr.Count -eq 0) {
            $mi0 = New-Object System.Windows.Controls.MenuItem
            $mi0.Header = 'nothing pinned'; $mi0.IsEnabled = $false
            $null = $mm.Items.Add($mi0)
        } else {
            foreach ($x in $arr) {
                $mi = New-Object System.Windows.Controls.MenuItem
                $mi.Header = 'remove · ' + [string]$x.Name
                $mi.Tag = [string]$x.Path
                $mi.Add_Click({ Remove-Launcher ([string]$sender.Tag) })
                $null = $mm.Items.Add($mi)
            }
        }
    } catch { Log-Crash 'manage' $_.Exception.Message }
})
$null = $menu.Items.Add($script:MiManage)
$null = $menu.Items.Add((New-MI 'clear clipboard shelf' { Clear-ClipboardShelf }))
$null = $menu.Items.Add((New-MI 'open island data folder' { try { $null = [System.Diagnostics.Process]::Start($script:DataDir) } catch { } }))
$null = $menu.Items.Add((New-MI 'screenshot auto-clean · on/off' {
    $script:Settings.ScrubShots = -not [bool]$script:Settings.ScrubShots
    Save-Settings
    Show-Toast ('screenshot auto-clean: ' + $(if ($script:Settings.ScrubShots) { 'on · recycle after ' + $script:Settings.RetainHrs + 'h' } else { 'off' }))
}))
$null = $menu.Items.Add((New-Object System.Windows.Controls.Separator))
$null = $menu.Items.Add((New-MI 'hover to open · toggle' {
    $script:Settings.HoverOpen = -not $script:Settings.HoverOpen
    Save-Settings
    Show-Toast ('hover-to-open: ' + ($(if ($script:Settings.HoverOpen) {'on'} else {'off'})))
}))
$null = $menu.Items.Add((New-MI 'hide in fullscreen · toggle' {
    $script:Settings.HideOnFS = -not [bool]$script:Settings.HideOnFS
    Save-Settings
    if ($window.Visibility -ne 'Visible') { $window.Visibility = 'Visible' }
    Show-Toast ('hide in fullscreen: ' + $(if ($script:Settings.HideOnFS) { 'on' } else { 'off' }))
}))
$null = $menu.Items.Add((New-MI 'always on top · toggle' {
    $script:Settings.Topmost = -not $script:Settings.Topmost
    $window.Topmost = $script:Settings.Topmost
    Save-Settings
}))
$null = $menu.Items.Add((New-MI 'launch at sign-in · toggle' {
    $now = -not (Test-RunAtStartup)
    Set-RunAtStartup $now
    Show-Toast ('launch at sign-in: ' + ($(if ($now) {'on'} else {'off'})))
}))
$null = $menu.Items.Add((New-MI 'send test notification' {
    Show-Toast ('test toast · ' + (Get-Date -Format 'HH:mm:ss'))
}))
$null = $menu.Items.Add((New-Object System.Windows.Controls.Separator))
$null = $menu.Items.Add((New-MI 'about island' {
    [System.Windows.MessageBox]::Show(
        "ISLAND - a floating system monitor for Windows`r`n`r`n" +
        "Hover or tap the pill to bloom it open · every tile is a button.`r`n" +
        "Push your own events into the island:`r`n" +
        "    Island.cmd 'Build #214 passed in 41s'`r`n`r`n" +
        "Zero install · zero admin · one PowerShell file.`r`n" +
        "Built in a single session with QwenWork - Alibaba Cloud workshop demo.",
        'Island') | Out-Null
}))
$null = $menu.Items.Add((New-MI 'exit island' { $app.Shutdown() }))
$uiCard.ContextMenu = $menu

# ------------------------------------------------- notify queue watcher ---
$script:QueueIdx = 0
function Read-Queue {
    if (-not (Test-Path $script:QueueFile)) { return }
    try { $lines = @(Get-Content -LiteralPath $script:QueueFile -Encoding UTF8 -ErrorAction Stop) } catch { return }
    if ($lines.Count -le $script:QueueIdx) {
        if ($lines.Count -lt $script:QueueIdx) {
            $script:QueueIdx = 0
            try { Clear-Content -LiteralPath $script:QueueFile } catch { }
        }
        return
    }
    $new = $lines[$script:QueueIdx..($lines.Count - 1)]
    $script:QueueIdx = $lines.Count
    foreach ($l in $new) {
        if (-not $l) { continue }
        $msg = if ($l.Contains('|')) { $l.Split('|', 2)[1] } else { $l }
        Show-Toast $msg
    }
}
# The file watcher's SynchronizingObject must be an ISynchronizeInvoke - a WPF
# Dispatcher is NOT (this exact line crashed v1-v3 on startup). Queue is instead
# polled on the UI thread by NotifyTimer below: same effect, zero thread risk.
Read-Queue

# --------------------------------------------------------------- tickers --
$script:ClockTimer = New-Object System.Windows.Threading.DispatcherTimer
$script:ClockTimer.Interval = [TimeSpan]::FromSeconds(1)
$script:ClockTimer.Add_Tick({
    try { Update-Clock } catch { Log-Crash 'clock' ($_.InvocationInfo.ScriptLineNumber.ToString() + ' ' + $_.Exception.Message) }
})

$script:NotifyTimer = New-Object System.Windows.Threading.DispatcherTimer
$script:NotifyTimer.Interval = [TimeSpan]::FromMilliseconds(900)
$script:NotifyTimer.Add_Tick({ try { Read-Queue } catch { } })

$script:SnapTimer = New-Object System.Windows.Threading.DispatcherTimer
$script:SnapTimer.Interval = [TimeSpan]::FromSeconds(2)
$script:SnapTimer.Add_Tick({
    try {
        $snap = Get-Snapshot
        Update-UI $snap
        Check-Alerts $snap
        Check-HardwareEvents
    } catch { Log-Crash 'tick' ($_.InvocationInfo.ScriptLineNumber.ToString() + ' ' + $_.Exception.Message) }
})

# hotkey Alt+I toggles the island (registered once the HWND exists)
$window.Add_SourceInitialized({
    param($s, $e)
    $hwnd = (New-Object System.Windows.Interop.WindowInteropHelper($window)).Handle
    [Island.Win]::Style($hwnd)
    try {
        $src = [System.Windows.Interop.HwndSource]::FromVisual($window)
        if ($src) {
            $null = [Island.HK]::RegisterHotKey($hwnd, 1, 0x0001, 0x49)
            $null = [Island.Win]::AddClipboardFormatListener($hwnd)
            $src.AddHook({
                param($h2, $msg, $wParam, $lParam, $handled)
                if ($msg -eq 0x031D) { try { Grab-ClipboardNow } catch { } ; return [IntPtr]::Zero }
                if ($msg -eq 0x0312 -and [int]$wParam -eq 1) {
                    if ($script:Parked -eq $true) { UnPark-Island }
                    if ($script:State -eq 'expanded') {
                        $script:PinOpen = $false
                        Invoke-State 'collapsed'
                    } else {
                        $script:PinOpen = $true
                        Invoke-State 'expanded'
                    }
                }
                return [IntPtr]::Zero
            })
        }
    } catch { }
})
$window.Add_KeyDown({
    param($s, $e)
    if ($e.Key -eq 'Escape' -and $script:State -eq 'expanded') {
        if ($script:Page -ne 'home') { Show-Page 'home'; return }
        $script:PinOpen = $false
        Invoke-State 'collapsed'
    }
})

if ($Once) {
    $t = New-Object System.Windows.Threading.DispatcherTimer
    $t.Interval = [TimeSpan]::FromSeconds(4)
    $t.Add_Tick({ Write-Host 'ISLAND_SMOKE_OK'; $app.Shutdown() })
    $t.Start()
}

# --------------------------------------------------------------- launch ---
$app = New-Object System.Windows.Application
$app.ShutdownMode = [System.Windows.ShutdownMode]::OnExplicitShutdown
$window.Add_Closed({ $app.Shutdown() })
$app.Dispatcher.add_UnhandledException({
    param($s, $e)
    $msg = [string]$e.Exception
    try { Add-Content -LiteralPath $script:CrashLog -Value ('{0}  dispatcher: {1}' -f (Get-Date -Format 'HH:mm:ss'), $msg) -Encoding UTF8 } catch { }
    if ($script:Debug) { Write-Host ("DISPATCHER " + $e.Exception.Message) -ForegroundColor Yellow }
    if ($msg -match 'RENDERTHREAD|88980406' -and -not $script:Respawned) {
        $script:Respawned = $true
        # render thread death: respawn a fresh island (software mode should prevent; this guarantees recovery)
        try {
            $self = $PSCommandPath
            $null = Start-Process powershell.exe -WindowStyle Hidden -ArgumentList ('-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f $self),'-Minimized','-Kill')
        } catch { }
        $e.Handled = $true
        $app.Shutdown()
        return
    }
    $e.Handled = $true
})

$window.Add_Loaded({
    param($s2, $e2)
    $window.Left = $script:CX - $window.Width / 2
    $window.Top  = $script:CY - 64
    $script:ClockTimer.Start()
    $script:SnapTimer.Start()
    $script:ShotTimer.Start()
    $script:NotifyTimer.Start()
    try {
        Update-Launchers
        Apply-HomeLayout
        Grab-ClipboardNow
        Render-RemindersPage
        Update-Screenshots
        Update-UI (Get-Snapshot)
    } catch { Log-Crash 'first-render' $_.Exception.Message }
    if ([bool]$script:Settings.FirstRun) {
        $script:Settings.FirstRun = $false
        Save-Settings
        After 1600 { Show-Toast 'drop shortcuts on me · i keep snaps 2h + clipboard history' }
    }
    Anim-El $window ([System.Windows.UIElement]::OpacityProperty) ([double]$script:Settings.Opacity) 650 150
    Anim-El $window ([System.Windows.Window]::TopProperty) $script:CY 650 150
    $script:ui.PillView.Opacity = 0
    $window.Opacity = [double]$script:Settings.Opacity
    try { ('{0}  shown   W{1} H{2}' -f (Get-Date -Format 'HH:mm:ss'), [int]$window.Width, [int]$window.Height) | Add-Content -LiteralPath (Join-Path $env:TEMP 'IslandPS-boot.log') -Encoding UTF8 } catch { }
    After 950 {
        $window.Top = $script:CY
        $window.Opacity = [double]$script:Settings.Opacity
        $window.BeginAnimation([System.Windows.Window]::TopProperty, $null)
        $window.BeginAnimation([System.Windows.UIElement]::OpacityProperty, $null)
    }
})

$app.Run($window)

# --------------------------------------------------------------- unload ---
try { $script:BgPS.Stop(); $script:BgRunspace.Dispose() } catch { }
try { $script:Mutex.ReleaseMutex() } catch { }
